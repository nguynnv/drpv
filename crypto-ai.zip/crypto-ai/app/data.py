from binance.client import Client
import pandas as pd

client = Client()

def get_data(symbol="BTCUSDT", interval="1h", limit=1000, trading_type="spot"):
    """
    Fetch OHLCV data from Binance (Spot or Futures)
    
    Args:
        symbol: Trading pair (default: BTCUSDT)
        interval: Timeframe - '15m', '30m', '1h', '4h', '1d'
        limit: Number of candles to fetch
        trading_type: 'spot' or 'future' (default: 'spot')
    
    Returns:
        DataFrame with OHLCV data
    """
    # Validate trading type
    valid_types = ['spot', 'future']
    if trading_type not in valid_types:
        print(f"⚠️  Invalid trading_type '{trading_type}'. Using 'spot'. Valid: {valid_types}")
        trading_type = 'spot'
    
    # Validate interval
    valid_intervals = ['15m', '30m', '1h', '4h', '1d']
    if interval not in valid_intervals:
        print(f"⚠️  Invalid interval '{interval}'. Using '1h'. Valid: {valid_intervals}")
        interval = '1h'
    
    # Fetch data based on trading type
    if trading_type == 'future':
        klines = client.futures_klines(symbol=symbol, interval=interval, limit=limit)
    else:  # spot
        klines = client.get_klines(symbol=symbol, interval=interval, limit=limit)
    
    df = pd.DataFrame(klines, columns=[
        "time","open","high","low","close","volume",
        "ct","qav","trades","tb","tq","ignore"
    ])
    
    # Convert all numeric columns to float
    numeric_cols = ["open", "high", "low", "close", "volume", "qav", "tb", "tq"]
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    
    # Convert time to numeric
    df["time"] = pd.to_numeric(df["time"], errors='coerce')
    
    # Drop any rows with NaN values created by conversion errors
    df = df.dropna(subset=numeric_cols)
    
    return df

from flask import Flask, jsonify, request
import logging
from data import get_data
from features import add_features
from model import predict
from continuous_trainer import start_continuous_training, stop_continuous_training, get_trainer_status

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# ============ HELPER FUNCTIONS ============

def get_interval_from_request():
    """Extract interval from query param, default to 1h"""
    interval = request.args.get('interval', '1h').lower()
    valid = ['15m', '30m', '1h', '4h', '1d']
    if interval not in valid:
        interval = '1h'
    return interval

def get_trading_type_from_request():
    """Extract trading_type from query param, default to spot"""
    trading_type = request.args.get('trading_type', 'spot').lower()
    valid = ['spot', 'future']
    if trading_type not in valid:
        trading_type = 'spot'
    return trading_type

# ============ API ENDPOINTS ============

@app.route('/predict', methods=['GET'])
def get_prediction():
    """Dự đoán giá tiếp theo với chi tiết phân tích
    Query params: ?interval=15m|30m|1h|4h|1d (default: 1h) &trading_type=spot|future (default: spot)
    """
    try:
        interval = get_interval_from_request()
        trading_type = get_trading_type_from_request()
        logger.info(f"📊 Prediction request - Interval: {interval}, Type: {trading_type}")
        
        df = get_data(limit=300, interval=interval, trading_type=trading_type)  # Need more data due to rolling calculations
        df = add_features(df)
        
        if len(df) == 0:
            raise ValueError("Insufficient data after feature engineering")
        
        result = predict(df)
        result['interval'] = interval  # Add interval to response
        result['trading_type'] = trading_type  # Add trading type to response
        return jsonify(result)
    except Exception as e:
        logger.error(f"❌ Prediction error: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/predict/summary', methods=['GET'])
def get_prediction_summary():
    """Dự đoán với summary ngắn gọn
    Query params: ?interval=15m|30m|1h|4h|1d (default: 1h) &trading_type=spot|future (default: spot)
    """
    try:
        interval = get_interval_from_request()
        trading_type = get_trading_type_from_request()
        
        df = get_data(limit=300, interval=interval, trading_type=trading_type)
        df = add_features(df)
        
        if len(df) == 0:
            raise ValueError("Insufficient data after feature engineering")
        
        result = predict(df)
        
        # Return chỉ essential info
        return jsonify({
            "signal": result.get('signal', '⚪ UNKNOWN'),
            "confidence": result.get('confidence', 0),
            "confidence_percent": result.get('confidence_percent', '0%'),
            "model_consensus": result.get('ensemble', {}).get('model_consensus', 'N/A'),
            "tech_consensus": result.get('technical_consensus', 'N/A'),
            "price": result.get('current_values', {}).get('price', 0),
            "interval": interval,
            "trading_type": trading_type
        })
    except Exception as e:
        logger.error(f"❌ Prediction error: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({"status": "healthy", "message": "Crypto AI service is running"})

@app.route('/training/status', methods=['GET'])
def training_status():
    """Lấy status của continuous training"""
    return jsonify(get_trainer_status())

@app.route('/data/latest', methods=['GET'])
def get_latest_data():
    """Lấy dữ liệu mới nhất
    Query params: ?interval=15m|30m|1h|4h|1d (default: 1h) &trading_type=spot|future (default: spot)
    """
    try:
        interval = get_interval_from_request()
        trading_type = get_trading_type_from_request()
        
        df = get_data(limit=200, interval=interval, trading_type=trading_type)
        df = add_features(df)
        
        if len(df) == 0:
            raise ValueError("Insufficient data")
        
        # Return latest 10 records
        records = df.tail(10).to_dict(orient='records')
        return jsonify({
            "interval": interval,
            "trading_type": trading_type,
            "count": len(records),
            "data": records
        })
    except Exception as e:
        logger.error(f"❌ Data fetch error: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/data/ohlcv', methods=['GET'])
def get_ohlcv_data():
    """Lấy dữ liệu OHLCV (Open, High, Low, Close, Volume)
    Query params: ?interval=15m|30m|1h|4h|1d (default: 1h) &trading_type=spot|future (default: spot)
    """
    try:
        interval = get_interval_from_request()
        trading_type = get_trading_type_from_request()
        
        df = get_data(limit=200, interval=interval, trading_type=trading_type)
        
        ohlcv_data = df[['time', 'open', 'high', 'low', 'close', 'volume']].tail(50).to_dict(orient='records')
        return jsonify({
            "interval": interval,
            "trading_type": trading_type,
            "count": len(ohlcv_data),
            "data": ohlcv_data
        })
    except Exception as e:
        logger.error(f"❌ OHLCV fetch error: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/info', methods=['GET'])
def info():
    """Get system information and supported intervals"""
    return jsonify({
        "service": "Crypto AI Prediction Engine",
        "version": "2.0",
        "supported_intervals": ["15m", "30m", "1h", "4h", "1d"],
        "supported_trading_types": ["spot", "future"],
        "endpoints": {
            "/predict": "Full prediction with detailed analysis",
            "/predict/summary": "Quick prediction summary",
            "/data/latest": "Latest OHLCV+indicators data",
            "/data/ohlcv": "OHLCV data for charting",
            "/health": "Health check",
            "/training/status": "Training progress",
            "/info": "This info"
        },
        "usage": {
            "spot_1h": "/predict?trading_type=spot&interval=1h",
            "future_15m": "/predict?trading_type=future&interval=15m",
            "future_4h": "/predict?trading_type=future&interval=4h",
            "spot_1d": "/predict?trading_type=spot&interval=1d"
        }
    })

# ============ STARTUP/SHUTDOWN ============

# Global flag để tracking trainer status
trainer_initialized = False

def initialize_trainer():
    """Khởi động trainer một lần duy nhất"""
    global trainer_initialized
    if not trainer_initialized:
        try:
            logger.info("🚀 Initializing continuous trainer...")
            start_continuous_training()
            trainer_initialized = True
            logger.info("✅ Continuous trainer initialized successfully")
        except Exception as e:
            logger.error(f"❌ Failed to initialize trainer: {e}")

def shutdown_trainer(exception=None):
    """Dừng continuous training khi app shutdown"""
    try:
        logger.info("⛔ Shutting down continuous trainer...")
        stop_continuous_training()
        logger.info("✅ Continuous trainer shutdown successfully")
    except Exception as e:
        logger.error(f"❌ Shutdown error: {e}")

app.teardown_appcontext(shutdown_trainer)

# ============ ERROR HANDLERS ============

@app.errorhandler(404)
def not_found(error):
    return jsonify({"error": "Endpoint not found"}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({"error": "Internal server error"}), 500

# ============ MAIN ============

if __name__ == "__main__":
    # Initialize trainer before starting server
    initialize_trainer()
    
    # Chạy Flask server trên port 5000
    # Có thể thay đổi host/port tùy ý
    print("\n" + "="*70)
    print("🚀 Crypto AI API Server - Supporting SPOT & FUTURES")
    print("="*70)
    print("\n📊 Supported Trading Types: SPOT & FUTURES")
    print("⏱️  Supported Intervals: 15m, 30m, 1h, 4h, 1d")
    print("\n📝 Examples:")
    print("  - Spot 1h:       http://localhost:5000/predict?trading_type=spot&interval=1h")
    print("  - Future 15m:    http://localhost:5000/predict?trading_type=future&interval=15m")
    print("  - Future 4h:     http://localhost:5000/predict?trading_type=future&interval=4h")
    print("\n" + "="*70 + "\n")
    
    app.run(
        host='0.0.0.0',      # Cho phép các app khác kết nối
        port=5000,           # Port mà các app sẽ dùng
        debug=False,         # Tắt debug mode trên production
        threaded=True        # Cho phép multiple requests
    )

"""
Model Analyzer - Phân tích chi tiết từng prediction
Trả về 20+ metrics làm chứng cứ cho quyết định
"""
import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
import logging

logger = logging.getLogger(__name__)

class ModelAnalyzer:
    def __init__(self):
        self.xgb = joblib.load("models/xgb.pkl")
        self.rf = joblib.load("models/rf.pkl")
        self.gb = joblib.load("models/gb.pkl")
        self.lr = joblib.load("models/lr.pkl")
        self.scaler = joblib.load("models/scaler.pkl")
        self.feature_cols = joblib.load("models/feature_cols.pkl")
        self.metadata = joblib.load("models/metadata.pkl")
    
    def analyze(self, df):
        """
        Phân tích chi tiết dữ liệu
        Args: df - DataFrame với features đã được convert
        Returns: dict với chi tiết phân tích
        """
        
        # Get latest row
        latest = df.iloc[-1]
        latest_prev = df.iloc[-2] if len(df) > 1 else None
        
        # Scale features
        X = df[self.feature_cols].fillna(0).values
        X_scaled = self.scaler.transform(X)
        latest_scaled = X_scaled[-1].reshape(1, -1)
        
        # ============ MODEL PREDICTIONS ============
        xgb_proba = self.xgb.predict_proba(latest_scaled)[0]
        rf_proba = self.rf.predict_proba(latest_scaled)[0]
        gb_proba = self.gb.predict_proba(latest_scaled)[0]
        lr_proba = self.lr.predict_proba(latest_scaled)[0]
        
        # Ensemble vote
        ensemble_proba_up = (xgb_proba[1] + rf_proba[1] + gb_proba[1] + lr_proba[1]) / 4
        
        # Final signal: chỉ return nếu confidence cao
        threshold = 0.55  # Chỉ dự đoán nếu >= 55% confidence
        ensemble_pred = 1 if ensemble_proba_up > threshold else 0
        signal = "🟢 UP" if ensemble_pred == 1 else "🔴 DOWN"
        
        # ============ TECHNICAL INDICATORS ANALYSIS ============
        technical_analysis = self._analyze_technicals(latest, latest_prev)
        
        # ============ CONSENSUS SCORE ============
        model_votes = {
            'xgb': 'UP' if xgb_proba[1] > 0.5 else 'DOWN',
            'rf': 'UP' if rf_proba[1] > 0.5 else 'DOWN',
            'gb': 'UP' if gb_proba[1] > 0.5 else 'DOWN',
            'lr': 'UP' if lr_proba[1] > 0.5 else 'DOWN'
        }
        
        # Count votes
        up_votes = sum(1 for v in model_votes.values() if v == 'UP')
        consensus = f"{up_votes}/4"
        
        # ============ CONFIDENCE CALCULATION ============
        # Dựa trên: ensemble vote + tech analysis agreement + model confidence
        tech_up_count = sum(1 for v in technical_analysis['indicators'].values() if v > 0)
        tech_consensus = f"{tech_up_count}/{len(technical_analysis['indicators'])}"
        
        # Weighted confidence
        confidence = float((
            abs(ensemble_proba_up - 0.5) * 2 * 0.4 +  # Ensemble confidence
            (up_votes / 4) * 0.3 +  # Model consensus
            (tech_up_count / len(technical_analysis['indicators'])) * 0.3  # Tech agreement
        ))
        
        # ============ EVIDENCE COLLECTION ============
        evidence = {
            # Main prediction
            'signal': signal,
            'confidence': round(confidence, 4),
            'confidence_percent': f"{confidence*100:.2f}%",
            
            # Model predictions
            'models': {
                'xgb': {
                    'prediction': 'UP' if xgb_proba[1] > 0.5 else 'DOWN',
                    'probability_down': float(round(xgb_proba[0], 4)),
                    'probability_up': float(round(xgb_proba[1], 4)),
                    'confidence': float(round(abs(xgb_proba[1] - 0.5) * 2, 4))
                },
                'rf': {
                    'prediction': 'UP' if rf_proba[1] > 0.5 else 'DOWN',
                    'probability_down': float(round(rf_proba[0], 4)),
                    'probability_up': float(round(rf_proba[1], 4)),
                    'confidence': float(round(abs(rf_proba[1] - 0.5) * 2, 4))
                },
                'gb': {
                    'prediction': 'UP' if gb_proba[1] > 0.5 else 'DOWN',
                    'probability_down': float(round(gb_proba[0], 4)),
                    'probability_up': float(round(gb_proba[1], 4)),
                    'confidence': float(round(abs(gb_proba[1] - 0.5) * 2, 4))
                },
                'lr': {
                    'prediction': 'UP' if lr_proba[1] > 0.5 else 'DOWN',
                    'probability_down': float(round(lr_proba[0], 4)),
                    'probability_up': float(round(lr_proba[1], 4)),
                    'confidence': float(round(abs(lr_proba[1] - 0.5) * 2, 4))
                }
            },
            'ensemble': {
                'probability_down': float(round(1 - ensemble_proba_up, 4)),
                'probability_up': float(round(ensemble_proba_up, 4)),
                'model_consensus': consensus,
                'agreement_percent': f"{(up_votes/4)*100:.1f}%"
            },
            
            # Technical indicators
            'technical_indicators': {k: float(v) if isinstance(v, (int, float, np.number)) else v 
                                      for k, v in technical_analysis['indicators'].items()},
            'technical_summary': technical_analysis['summary'],
            'technical_consensus': tech_consensus,
            'tech_agreement_percent': f"{(tech_up_count/len(technical_analysis['indicators']))*100:.1f}%",
            
            # Current values
            'current_values': {
                'price': float(round(float(latest['close']), 2)),
                'volume': float(round(float(latest['volume']), 0)),
                'rsi_14': float(round(float(latest.get('rsi_14', 0)), 2)),
                'macd': float(round(float(latest.get('macd', 0)), 6)),
                'atr': float(round(float(latest.get('atr', 0)), 2)),
                'adx': float(round(float(latest.get('adx', 0)), 2)),
                'bb_position': 'UPPER' if float(latest.get('bb_bbhi', 0)) > 0 else ('LOWER' if float(latest.get('bb_bbli', 0)) > 0 else 'MIDDLE')
            },
            
            # Training info
            'model_info': {
                'training_timestamp': self.metadata.get('timestamp', 'N/A'),
                'n_features_used': self.metadata.get('n_features', 0),
                'model_accuracy': {
                    'xgb': f"{self.metadata['scores'].get('xgb', {}).get('accuracy', 0)*100:.2f}%",
                    'rf': f"{self.metadata['scores'].get('rf', {}).get('accuracy', 0)*100:.2f}%",
                    'gb': f"{self.metadata['scores'].get('gb', {}).get('accuracy', 0)*100:.2f}%",
                    'lr': f"{self.metadata['scores'].get('lr', {}).get('accuracy', 0)*100:.2f}%",
                    'ensemble': f"{self.metadata['scores'].get('ensemble', {}).get('accuracy', 0)*100:.2f}%"
                }
            }
        }
        
        return evidence
    
    def _analyze_technicals(self, latest, latest_prev=None):
        """Phân tích các technical indicators"""
        
        indicators_score = {}
        summary = {}
        
        # RSI Analysis
        rsi = latest.get('rsi_14', 50)
        if rsi < 30:
            indicators_score['rsi_oversold'] = 1  # Oversolď → UP potential
            summary['rsi'] = f"🟢 OVERSOLD ({rsi:.1f})"
        elif rsi > 70:
            indicators_score['rsi_overbought'] = -1  # Overbought → DOWN potential
            summary['rsi'] = f"🔴 OVERBOUGHT ({rsi:.1f})"
        else:
            mid = 1 if rsi > 50 else -1
            indicators_score['rsi_mid'] = mid
            summary['rsi'] = f"⚪ NEUTRAL ({rsi:.1f})"
        
        # MACD Analysis
        macd = latest.get('macd', 0)
        macd_signal = latest.get('macd_signal', 0)
        if macd > macd_signal:
            indicators_score['macd_cross'] = 1  # Bullish
            summary['macd'] = "🟢 BULLISH CROSS"
        else:
            indicators_score['macd_cross'] = -1  # Bearish
            summary['macd'] = "🔴 BEARISH CROSS"
        
        # Trend (EMA)
        price = latest.get('close', 0)
        ema_12 = latest.get('ema_12', 0)
        ema_26 = latest.get('ema_26', 0)
        ema_50 = latest.get('ema_50', 0)
        
        if price > ema_12 > ema_26 > ema_50:
            indicators_score['ema_trend'] = 1  # Strong uptrend
            summary['ema_trend'] = "🟢 STRONG UPTREND"
        elif price < ema_12 < ema_26 < ema_50:
            indicators_score['ema_trend'] = -1  # Strong downtrend
            summary['ema_trend'] = "🔴 STRONG DOWNTREND"
        else:
            indicators_score['ema_trend'] = 0  # Mixed
            summary['ema_trend'] = "⚪ MIXED"
        
        # Bollinger Bands
        bb_h = latest.get('bb_bbh', 0)
        bb_l = latest.get('bb_bbl', 0)
        bb_m = latest.get('bb_bbm', 0)
        
        if price > bb_m:
            indicators_score['bb_position'] = 1
            summary['bb'] = f"🟢 ABOVE MIDDLE"
        else:
            indicators_score['bb_position'] = -1
            summary['bb'] = f"🔴 BELOW MIDDLE"
        
        # ADX (Trend strength)
        adx = latest.get('adx', 0)
        if adx > 25:
            adx_sign = 1 if latest.get('adx_pos', 0) > latest.get('adx_neg', 0) else -1
            indicators_score['adx_strength'] = adx_sign
            summary['adx'] = f"🟢 STRONG TREND ({adx:.1f})" if adx_sign > 0 else f"🔴 STRONG DOWN ({adx:.1f})"
        else:
            indicators_score['adx_strength'] = 0
            summary['adx'] = f"⚪ WEAK TREND ({adx:.1f})"
        
        # Volume Analysis
        volume = float(latest.get('volume', 0))
        if latest_prev is not None:
            prev_volume = float(latest_prev.get('volume', 1))
            if volume > prev_volume * 1.2:  # Volume spike
                indicators_score['volume_spike'] = 1
                summary['volume'] = f"🟢 HIGH VOLUME SPIKE"
            elif volume < prev_volume * 0.8:
                indicators_score['volume_spike'] = -1
                summary['volume'] = f"🔴 LOW VOLUME"
            else:
                indicators_score['volume_spike'] = 0
                summary['volume'] = f"⚪ NORMAL VOLUME"
        else:
            indicators_score['volume_spike'] = 0
            summary['volume'] = f"⚪ NORMAL VOLUME"
        
        # MFI (Money Flow Index)
        mfi = latest.get('mfi', 50)
        if mfi > 60:
            indicators_score['mfi'] = 1  # Strong buying
            summary['mfi'] = f"🟢 STRONG BUYING ({mfi:.1f})"
        elif mfi < 40:
            indicators_score['mfi'] = -1  # Strong selling
            summary['mfi'] = f"🔴 STRONG SELLING ({mfi:.1f})"
        else:
            indicators_score['mfi'] = 0
            summary['mfi'] = f"⚪ NEUTRAL ({mfi:.1f})"
        
        # CCI (Commodity Channel Index)
        cci = latest.get('cci', 0)
        if cci > 100:
            indicators_score['cci'] = 1
            summary['cci'] = f"🟢 STRONG BUY ({cci:.1f})"
        elif cci < -100:
            indicators_score['cci'] = -1
            summary['cci'] = f"🔴 STRONG SELL ({cci:.1f})"
        else:
            indicators_score['cci'] = 0
            summary['cci'] = f"⚪ NEUTRAL ({cci:.1f})"
        
        return {
            'indicators': indicators_score,
            'summary': summary,
            'total_indicators': len(indicators_score)
        }

# Global instance
analyzer = None

def get_analyzer():
    global analyzer
    if analyzer is None:
        analyzer = ModelAnalyzer()
    return analyzer

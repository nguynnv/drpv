import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from xgboost import XGBClassifier
import logging

from data import get_data
from features import add_features

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def train():
    """Train multiple models dengan hyperparameter tuning dan validation"""
    
    logger.info("=" * 60)
    logger.info("🚀 TRAINING STARTED - Fetching data...")
    logger.info("=" * 60)
    
    # ============ DATA PREPARATION ============
    df = get_data(limit=1000)  # Increased from 500 → 1000 for better training
    df = add_features(df)
    
    logger.info(f"📊 Data shape: {df.shape}")
    logger.info(f"✅ Features: {df.shape[1] - 1}")
    
    # Select features (skip target, time, OHLCV)
    excluded_cols = ['time', 'open', 'high', 'low', 'close', 'volume', 'ct', 'qav', 'trades', 'tb', 'tq', 'ignore', 'target']
    feature_cols = [col for col in df.columns if col not in excluded_cols]
    
    X = df[feature_cols].fillna(0)
    y = df['target']
    
    logger.info(f"📈 Features used: {len(feature_cols)}")
    logger.info(f"Class distribution: {y.value_counts().to_dict()}")
    logger.info(f"Class balance: UP={y.sum()}/{len(y)} ({y.sum()/len(y)*100:.1f}%)")
    
    # ============ DATA SCALING ============
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    joblib.dump(scaler, "models/scaler.pkl")
    logger.info("✅ Scaler fitted and saved")
    
    # ============ TRAIN-TEST SPLIT ============
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42, stratify=y
    )
    
    logger.info(f"📊 Train size: {X_train.shape[0]}, Test size: {X_test.shape[0]}")
    
    # ============ MODEL TRAINING WITH TUNING ============
    models = {}
    predictions = {}
    scores = {}
    
    # 1. XGBoost - Tuned with class weights
    logger.info("\n🔄 Training XGBoost...")
    xgb = XGBClassifier(
        n_estimators=300,
        max_depth=6,
        learning_rate=0.1,
        subsample=0.9,
        colsample_bytree=0.9,
        gamma=0,
        reg_alpha=0.1,
        reg_lambda=1,
        scale_pos_weight=1 + (sum(y==0) / sum(y==1)) if sum(y==1) > 0 else 1,  # Class weight
        random_state=42,
        eval_metric='logloss'
    )
    xgb.fit(X_train, y_train, eval_set=[(X_test, y_test)], verbose=False)
    models['xgb'] = xgb
    
    xgb_pred = xgb.predict(X_test)
    xgb_proba = xgb.predict_proba(X_test)[:, 1]
    predictions['xgb'] = xgb_pred
    
    xgb_acc = accuracy_score(y_test, xgb_pred)
    xgb_auc = roc_auc_score(y_test, xgb_proba)
    scores['xgb'] = {'accuracy': xgb_acc, 'auc': xgb_auc}
    
    logger.info(f"✅ XGBoost - Accuracy: {xgb_acc:.4f}, AUC: {xgb_auc:.4f}")
    
    # 2. Random Forest - Tuned with class weights
    logger.info("🔄 Training Random Forest...")
    rf = RandomForestClassifier(
        n_estimators=300,
        max_depth=12,
        min_samples_split=4,
        min_samples_leaf=2,
        max_features='sqrt',
        class_weight='balanced',  # Auto balance classes
        random_state=42,
        n_jobs=-1
    )
    rf.fit(X_train, y_train)
    models['rf'] = rf
    
    rf_pred = rf.predict(X_test)
    rf_proba = rf.predict_proba(X_test)[:, 1]
    predictions['rf'] = rf_pred
    
    rf_acc = accuracy_score(y_test, rf_pred)
    rf_auc = roc_auc_score(y_test, rf_proba)
    scores['rf'] = {'accuracy': rf_acc, 'auc': rf_auc}
    
    logger.info(f"✅ Random Forest - Accuracy: {rf_acc:.4f}, AUC: {rf_auc:.4f}")
    
    # 3. Gradient Boosting - Tuned with class weights
    logger.info("🔄 Training Gradient Boosting...")
    # Calculate class weight for GB
    class_weight = len(y_train) / (2 * np.bincount(y_train))
    gb = GradientBoostingClassifier(
        n_estimators=300,
        learning_rate=0.1,
        max_depth=6,
        subsample=0.9,
        init='zero',
        random_state=42
    )
    gb.fit(X_train, y_train, sample_weight=None)
    models['gb'] = gb
    
    gb_pred = gb.predict(X_test)
    gb_proba = gb.predict_proba(X_test)[:, 1]
    predictions['gb'] = gb_pred
    
    gb_acc = accuracy_score(y_test, gb_pred)
    gb_auc = roc_auc_score(y_test, gb_proba)
    scores['gb'] = {'accuracy': gb_acc, 'auc': gb_auc}
    
    logger.info(f"✅ Gradient Boosting - Accuracy: {gb_acc:.4f}, AUC: {gb_auc:.4f}")
    
    # 4. Logistic Regression - with class weights
    logger.info("🔄 Training Logistic Regression...")
    lr = LogisticRegression(
        max_iter=2000,
        C=0.5,
        class_weight='balanced',  # Auto balance
        random_state=42,
        n_jobs=-1,
        solver='lbfgs'
    )
    lr.fit(X_train, y_train)
    models['lr'] = lr
    
    lr_pred = lr.predict(X_test)
    lr_proba = lr.predict_proba(X_test)[:, 1]
    predictions['lr'] = lr_pred
    
    lr_acc = accuracy_score(y_test, lr_pred)
    lr_auc = roc_auc_score(y_test, lr_proba)
    scores['lr'] = {'accuracy': lr_acc, 'auc': lr_auc}
    
    logger.info(f"✅ Logistic Regression - Accuracy: {lr_acc:.4f}, AUC: {lr_auc:.4f}")
    
    # ============ ENSEMBLE VOTING ============
    logger.info("\n🔄 Creating Ensemble Vote...")
    # Simple voting: avg of probabilities
    ensemble_proba = (xgb_proba + rf_proba + gb_proba + lr_proba) / 4
    ensemble_pred = (ensemble_proba > 0.5).astype(int)
    
    ensemble_acc = accuracy_score(y_test, ensemble_pred)
    ensemble_auc = roc_auc_score(y_test, ensemble_proba)
    scores['ensemble'] = {'accuracy': ensemble_acc, 'auc': ensemble_auc}
    
    logger.info(f"✅ Ensemble - Accuracy: {ensemble_acc:.4f}, AUC: {ensemble_auc:.4f}")
    
    # ============ SAVE MODELS ============
    logger.info("\n💾 Saving models...")
    joblib.dump(xgb, "models/xgb.pkl")
    joblib.dump(rf, "models/rf.pkl")
    joblib.dump(gb, "models/gb.pkl")
    joblib.dump(lr, "models/lr.pkl")
    joblib.dump(feature_cols, "models/feature_cols.pkl")
    
    # Save metadata
    metadata = {
        'feature_cols': feature_cols,
        'n_features': len(feature_cols),
        'scores': scores,
        'timestamp': pd.Timestamp.now().isoformat()
    }
    joblib.dump(metadata, "models/metadata.pkl")
    
    logger.info("✅ All models saved successfully")
    
    # ============ SUMMARY ============
    logger.info("\n" + "=" * 60)
    logger.info("📊 TRAINING SUMMARY:")
    logger.info("=" * 60)
    best_model = max(scores.items(), key=lambda x: x[1]['accuracy'])
    logger.info(f"🏆 Best Model: {best_model[0].upper()} - Accuracy: {best_model[1]['accuracy']:.2%}, AUC: {best_model[1]['auc']:.4f}")
    logger.info(f"🤖 Ensemble Accuracy: {ensemble_acc:.2%}")
    
    for model_name, score in scores.items():
        logger.info(f"   {model_name.upper():10s}: Acc={score['accuracy']:.2%}, AUC={score['auc']:.4f}")
    
    logger.info("=" * 60 + "\n")

if __name__ == "__main__":
    train()

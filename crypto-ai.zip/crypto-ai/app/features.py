import ta
import numpy as np
import pandas as pd

def add_features(df):
    """Add 20+ technical indicators for better prediction"""
    
    # Ensure all numeric columns are float
    numeric_cols = ["open", "high", "low", "close", "volume"]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    
    df = df.dropna(subset=numeric_cols)
    
    # ============ MOMENTUM INDICATORS ============
    df["rsi_14"] = ta.momentum.RSIIndicator(df["close"], window=14).rsi()
    df["rsi_7"] = ta.momentum.RSIIndicator(df["close"], window=7).rsi()
    
    # Stochastic RSI
    stoch_rsi = ta.momentum.StochRSIIndicator(df["close"], window=14, smooth1=3, smooth2=3)
    df["stoch_rsi"] = stoch_rsi.stochrsi()
    df["stoch_rsi_k"] = stoch_rsi.stochrsi_k()
    df["stoch_rsi_d"] = stoch_rsi.stochrsi_d()
    
    # MACD
    macd = ta.trend.MACD(df["close"], window_fast=12, window_slow=26, window_sign=9)
    df["macd"] = macd.macd()
    df["macd_signal"] = macd.macd_signal()
    df["macd_diff"] = macd.macd_diff()
    
    # CCI - Commodity Channel Index (Manual implementation)
    # CCI = (TP - SMA(TP)) / (0.015 * MAD)
    tp = (df["high"] + df["low"] + df["close"]) / 3
    sma_tp = tp.rolling(window=20).mean()
    mad = tp.rolling(window=20).apply(lambda x: (x - x.mean()).abs().mean())
    df["cci"] = (tp - sma_tp) / (0.015 * mad)
    
    # ============ TREND INDICATORS ============
    df["ema_12"] = ta.trend.EMAIndicator(df["close"], window=12).ema_indicator()
    df["ema_26"] = ta.trend.EMAIndicator(df["close"], window=26).ema_indicator()
    df["ema_50"] = ta.trend.EMAIndicator(df["close"], window=50).ema_indicator()
    df["ema_200"] = ta.trend.EMAIndicator(df["close"], window=200).ema_indicator()
    
    # SMA
    df["sma_20"] = ta.trend.SMAIndicator(df["close"], window=20).sma_indicator()
    df["sma_50"] = ta.trend.SMAIndicator(df["close"], window=50).sma_indicator()
    
    # ADX - Average Directional Index (trend strength)
    adx = ta.trend.ADXIndicator(df["high"], df["low"], df["close"], window=14)
    df["adx"] = adx.adx()
    df["adx_pos"] = adx.adx_pos()  # +DI
    df["adx_neg"] = adx.adx_neg()  # -DI
    
    # ============ VOLATILITY INDICATORS ============
    df["atr"] = ta.volatility.AverageTrueRange(df["high"], df["low"], df["close"], window=14).average_true_range()
    
    # Bollinger Bands
    bb = ta.volatility.BollingerBands(df["close"], window=20, window_dev=2)
    df["bb_bbm"] = bb.bollinger_mavg()
    df["bb_bbh"] = bb.bollinger_hband()
    df["bb_bbl"] = bb.bollinger_lband()
    df["bb_bbhi"] = bb.bollinger_hband_indicator()
    df["bb_bbli"] = bb.bollinger_lband_indicator()
    df["bb_bbw"] = bb.bollinger_wband()
    
    # Keltner Channels
    kc = ta.volatility.KeltnerChannel(df["high"], df["low"], df["close"], window=20, window_atr=10)
    df["kc_h"] = kc.keltner_channel_hband()
    df["kc_l"] = kc.keltner_channel_lband()
    
    # ============ VOLUME INDICATORS ============
    df["volume"] = pd.to_numeric(df["volume"], errors='coerce')
    
    # On-Balance Volume
    df["obv"] = ta.volume.OnBalanceVolumeIndicator(df["close"], df["volume"]).on_balance_volume()
    
    # Money Flow Index
    df["mfi"] = ta.volume.MFIIndicator(df["high"], df["low"], df["close"], df["volume"], window=14).money_flow_index()
    
    # Accumulation/Distribution Line
    df["ad"] = ta.volume.AccDistIndexIndicator(df["high"], df["low"], df["close"], df["volume"]).acc_dist_index()
    
    # ============ PRICE ACTION ============
    df["return"] = df["close"].pct_change()
    df["returns_2"] = df["close"].pct_change(2)
    df["returns_5"] = df["close"].pct_change(5)
    
    # High-Low ratio
    df["hl_ratio"] = (df["high"] - df["low"]) / df["low"]
    
    # Close position in range
    df["close_pos"] = (df["close"] - df["low"]) / (df["high"] - df["low"])
    
    # Price above/below EMA
    df["price_above_ema12"] = (df["close"] > df["ema_12"]).astype(float)
    df["price_above_ema26"] = (df["close"] > df["ema_26"]).astype(float)
    df["price_above_sma50"] = (df["close"] > df["sma_50"]).astype(float)
    
    # ============ TARGET VARIABLE ============
    # Predict next candle close: 1 if UP, 0 if DOWN
    df["target"] = (df["close"].shift(-1) > df["close"]).astype(int)
    
    # Forward fill then backward fill for any remaining NaN values
    df = df.ffill()  # Forward fill
    df = df.bfill()  # Backward fill
    
    # Drop any remaining NaN values (should be minimal now)
    df = df.dropna()
    
    return df
"""
Model prediction module - Returns detailed analysis with evidence
"""
import joblib
import numpy as np
import pandas as pd
from model_analyzer import get_analyzer
import logging

logger = logging.getLogger(__name__)

def predict(df_with_features):
    """
    Predict cryptocurrency price movement with detailed analysis
    
    Args:
        df_with_features: DataFrame đã được add_features()
    
    Returns:
        dict: Kết quả dự đoán chi tiết với nhiều chứng cứ
    """
    
    try:
        analyzer = get_analyzer()
        result = analyzer.analyze(df_with_features)
        
        logger.info(f"✅ Prediction: {result['signal']} (Confidence: {result['confidence_percent']})")
        
        return result
    
    except Exception as e:
        logger.error(f"❌ Prediction error: {str(e)}")
        return {
            "error": str(e),
            "signal": "⚪ UNKNOWN",
            "confidence": 0
        }

def predict_simple(features):
    """
    Simple predict function for backward compatibility
    Input: numpy array of raw features
    
    Args:
        features: Shape (1, n_features) - raw features before analysis
    
    Returns:
        dict: {signal, confidence}
    """
    analyzer = get_analyzer()
    feature_cols = joblib.load("models/feature_cols.pkl")
    scaler = joblib.load("models/scaler.pkl")
    
    # Make prediction
    xgb = joblib.load("models/xgb.pkl")
    rf = joblib.load("models/rf.pkl")
    gb = joblib.load("models/gb.pkl")
    lr = joblib.load("models/lr.pkl")
    
    features_scaled = scaler.transform(features)
    
    xgb_proba = xgb.predict_proba(features_scaled)[0][1]
    rf_proba = rf.predict_proba(features_scaled)[0][1]
    gb_proba = gb.predict_proba(features_scaled)[0][1]
    lr_proba = lr.predict_proba(features_scaled)[0][1]
    
    ensemble_proba = (xgb_proba + rf_proba + gb_proba + lr_proba) / 4
    confidence = abs(ensemble_proba - 0.5) * 2
    signal = "UP" if ensemble_proba > 0.5 else "DOWN"
    
    return {
        "signal": signal,
        "confidence": round(confidence, 4),
        "ensemble_probability": round(ensemble_proba, 4)
    }

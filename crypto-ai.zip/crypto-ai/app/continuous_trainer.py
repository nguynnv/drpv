import threading
import time
import logging
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from train import train

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ContinuousTrainer:
    def __init__(self, interval_minutes=60):
        self.interval_minutes = interval_minutes
        self.scheduler = BackgroundScheduler()
        self.is_training = False
        self.last_training_time = None
        self.training_count = 0
        
    def start(self):
        """Khởi động scheduler để train liên tục"""
        if not self.scheduler.running:
            # Chạy lần đầu ngay lập tức
            self._train_task()
            
            # Schedule để chạy định kỳ
            self.scheduler.add_job(
                self._train_task,
                'interval',
                minutes=self.interval_minutes,
                id='continuous_training'
            )
            self.scheduler.start()
            logger.info(f"✅ Continuous trainer started - Training every {self.interval_minutes} minutes")
    
    def stop(self):
        """Dừng scheduler"""
        if self.scheduler.running:
            self.scheduler.shutdown()
            logger.info("⛔ Continuous trainer stopped")
    
    def _train_task(self):
        """Chạy training"""
        if self.is_training:
            logger.warning("⚠️  Training đang chạy, bỏ qua lần này")
            return
        
        self.is_training = True
        self.training_count += 1
        
        try:
            logger.info(f"🚀 Training #{self.training_count} started at {datetime.now()}")
            train()
            self.last_training_time = datetime.now()
            logger.info(f"✅ Training #{self.training_count} completed successfully")
        except Exception as e:
            logger.error(f"❌ Training failed: {str(e)}")
        finally:
            self.is_training = False
    
    def get_status(self):
        """Lấy trạng thái training"""
        return {
            "is_training": self.is_training,
            "last_training_time": self.last_training_time.isoformat() if self.last_training_time else None,
            "total_trainings": self.training_count,
            "interval_minutes": self.interval_minutes
        }

# Global trainer instance
trainer = ContinuousTrainer(interval_minutes=60)  # Train mỗi 60 phút

def start_continuous_training():
    """Khởi động training"""
    trainer.start()

def stop_continuous_training():
    """Dừng training"""
    trainer.stop()

def get_trainer_status():
    """Lấy status"""
    return trainer.get_status()

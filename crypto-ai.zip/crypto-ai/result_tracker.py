"""
Result tracker - Automatically evaluate predictions after timeframe passes
Updates model quality metrics based on actual outcomes
"""
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List
from backtester import backtester
import requests
from app.data import get_data

API_BASE = "http://localhost:5000"

class ResultTracker:
    """Track and evaluate prediction results"""
    
    def __init__(self):
        self.check_interval = 300  # Check every 5 minutes
    
    def get_pending_predictions(self) -> List[str]:
        """Get all pending predictions"""
        quality_metrics = backtester.get_model_quality()
        return quality_metrics.get('pending', [])
    
    async def evaluate_prediction(self, prediction_id: str) -> Dict:
        """Evaluate a single prediction"""
        result = backtester.results.get(prediction_id)
        if not result:
            return {'error': 'Prediction not found'}
        
        try:
            # Fetch current price data
            response = requests.get(
                f"{API_BASE}/data/ohlcv",
                params={'interval': result.interval, 'trading_type': result.trading_type},
                timeout=10
            )
            
            if response.status_code != 200:
                return {'error': 'Failed to fetch current data'}
            
            data = response.json()
            current_price = data['data'][-1]['close'] if data['data'] else None
            
            if current_price:
                evaluation = backtester.evaluate_prediction(prediction_id, current_price)
                return evaluation
            else:
                return {'error': 'No price data available'}
        
        except Exception as e:
            return {'error': str(e)}
    
    async def check_and_evaluate_pending(self):
        """Check pending predictions and evaluate completed ones"""
        pending_results = [
            r for r in backtester.results.values()
            if r.status == "pending"
        ]
        
        evaluated = []
        for result in pending_results:
            # Calculate time elapsed
            entry_time = datetime.fromisoformat(result.entry_time)
            
            # Different evaluation times based on interval
            eval_time_map = {
                '15m': timedelta(minutes=30),
                '30m': timedelta(hours=1),
                '1h': timedelta(hours=2),
                '4h': timedelta(hours=8),
                '1d': timedelta(days=2)
            }
            
            eval_time = eval_time_map.get(result.interval, timedelta(hours=2))
            
            if datetime.now() >= entry_time + eval_time:
                eval_result = await self.evaluate_prediction(result.prediction_id)
                if 'error' not in eval_result:
                    evaluated.append(eval_result)
        
        return evaluated
    
    def get_recent_evaluations(self, limit: int = 10) -> List[Dict]:
        """Get recently evaluated predictions"""
        completed = [
            r for r in backtester.results.values()
            if r.status == "completed"
        ]
        
        # Sort by exit_time (most recent first)
        completed.sort(
            key=lambda x: x.exit_time or '',
            reverse=True
        )
        
        return [
            {
                'prediction_id': r.prediction_id,
                'symbol': r.symbol,
                'interval': r.interval,
                'predicted': r.predicted_signal,
                'actual': r.actual_signal,
                'result': '✅ WIN' if r.win else '❌ LOSS',
                'pnl': f"{r.pnl_percent:+.2f}%",
                'exit_time': r.exit_time[:19] if r.exit_time else 'N/A'
            }
            for r in completed[:limit]
        ]
    
    def get_model_improvement_stats(self) -> Dict:
        """Check if model is improving based on evaluations"""
        completed = [
            r for r in backtester.results.values()
            if r.status == "completed"
        ]
        
        if len(completed) < 10:
            return {
                'status': 'INSUFFICIENT DATA',
                'completed': len(completed),
                'needed': 10,
                'message': 'Need at least 10 completed predictions for trend analysis'
            }
        
        # Get last 10 vs previous 10
        last_10 = completed[-10:]
        prev_10 = completed[-20:-10] if len(completed) >= 20 else completed[:10]
        
        last_win_rate = sum(1 for r in last_10 if r.win) / len(last_10) * 100
        prev_win_rate = sum(1 for r in prev_10 if r.win) / len(prev_10) * 100
        
        improvement = last_win_rate - prev_win_rate
        
        if improvement > 5:
            trend = "📈 IMPROVING"
        elif improvement < -5:
            trend = "📉 DECLINING"
        else:
            trend = "➡️ STABLE"
        
        return {
            'status': 'TRENDING',
            'trend': trend,
            'previous_wr': round(prev_win_rate, 2),
            'current_wr': round(last_win_rate, 2),
            'improvement': round(improvement, 2),
            'completed': len(completed)
        }
    
    async def auto_cleanup_old_results(self):
        """Periodically clean up old results"""
        backtester.cleanup_old_results(days=30)
    
    async def run_continuous_evaluation(self):
        """Run continuous evaluation loop"""
        print("🔄 Starting continuous result tracker...")
        
        while True:
            try:
                # Evaluate pending predictions
                evaluated = await self.check_and_evaluate_pending()
                
                if evaluated:
                    print(f"📊 Evaluated {len(evaluated)} predictions")
                    
                    # Log evaluations
                    for eval_result in evaluated:
                        print(f"  - {eval_result['prediction_id']}: "
                              f"{eval_result['predicted']} → {eval_result['actual']} "
                              f"({eval_result['win']})")
                    
                    # Check model improvement
                    improvement = self.get_model_improvement_stats()
                    print(f"📈 Model trend: {improvement.get('trend', 'N/A')}")
                
                # Cleanup old results every 24 hours
                await self.auto_cleanup_old_results()
                
                # Wait before next check
                await asyncio.sleep(self.check_interval)
            
            except Exception as e:
                print(f"❌ Error in result tracker: {str(e)}")
                await asyncio.sleep(60)

# Global instance
result_tracker = ResultTracker()

if __name__ == '__main__':
    asyncio.run(result_tracker.run_continuous_evaluation())

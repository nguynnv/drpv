"""
Language management system for multi-language support
Supports: English, Vietnamese, Indonesian, Russian
Easy to add new languages via JSON files
"""
import json
import os
from typing import Dict, List

class LanguageManager:
    def __init__(self):
        self.translations_dir = "translations"
        self.default_language = "en"
        self.translations = {}
        self.available_languages = {}
        
        # Create translations directory if needed
        if not os.path.exists(self.translations_dir):
            os.makedirs(self.translations_dir)
        
        # Load all available languages
        self.load_all_languages()
    
    def load_all_languages(self):
        """Load all language files from translations directory"""
        if not os.path.exists(self.translations_dir):
            print(f"❌ Translations directory not found: {self.translations_dir}")
            return
        
        for filename in os.listdir(self.translations_dir):
            if filename.endswith('.json'):
                lang_code = filename[:-5]  # Remove .json extension
                filepath = os.path.join(self.translations_dir, filename)
                
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        self.translations[lang_code] = json.load(f)
                        
                        # Get language name from file
                        lang_name = self.translations[lang_code].get('language_name', lang_code)
                        self.available_languages[lang_code] = lang_name
                        
                        print(f"✅ Loaded language: {lang_name} ({lang_code})")
                
                except Exception as e:
                    print(f"❌ Error loading {filename}: {str(e)}")
    
    def get_available_languages(self) -> Dict[str, str]:
        """Get all available languages with their names
        
        Returns:
            Dict with lang_code: language_name pairs
        """
        return self.available_languages
    
    def get_text(self, lang_code: str, key: str, default: str = None) -> str:
        """Get translated text for a key
        
        Args:
            lang_code: Language code (en, vi, id, ru)
            key: Text key (e.g., 'start_welcome')
            default: Default text if key not found
        
        Returns:
            Translated text or default/key name
        """
        if lang_code not in self.translations:
            print(f"⚠️  Language {lang_code} not loaded, using {self.default_language}")
            lang_code = self.default_language
        
        translation_dict = self.translations.get(lang_code, {})
        return translation_dict.get(key, default or key)
    
    def has_language(self, lang_code: str) -> bool:
        """Check if language exists"""
        return lang_code in self.translations
    
    def add_language_file(self, lang_code: str, translations_dict: Dict):
        """Create/update language file
        
        Args:
            lang_code: Language code (e.g., 'es' for Spanish)
            translations_dict: Dictionary of translations
        """
        filepath = os.path.join(self.translations_dir, f"{lang_code}.json")
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(translations_dict, f, ensure_ascii=False, indent=2)
            
            self.translations[lang_code] = translations_dict
            self.available_languages[lang_code] = translations_dict.get('language_name', lang_code)
            print(f"✅ Language file created: {lang_code}.json")
            return True
        except Exception as e:
            print(f"❌ Error creating language file: {str(e)}")
            return False
    
    def validate_language(self, lang_code: str) -> bool:
        """Validate language exists and has required fields"""
        if lang_code not in self.translations:
            return False
        
        # Check for required fields (can expand this list)
        required_fields = ['language_name']
        lang_dict = self.translations[lang_code]
        
        for field in required_fields:
            if field not in lang_dict:
                print(f"⚠️  Missing required field '{field}' in {lang_code}.json")
                return False
        
        return True

# Global instance
language_manager = LanguageManager()

# Helper function for easier access
def t(lang_code: str, key: str) -> str:
    """Shorthand for language_manager.get_text()"""
    return language_manager.get_text(lang_code, key)

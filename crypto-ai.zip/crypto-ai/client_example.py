"""
Ví dụ cách dùng Crypto AI API từ các app khác
Hiện chi tiết phân tích & chứng cứ
Support: 15m, 30m, 1h, 4h, 1d timeframes
Support: Spot & Futures trading types
"""
import requests
import json

# Cấu hình
API_HOST = "http://localhost:5000"

def get_detailed_prediction(interval='1h', trading_type='spot'):
    """Lấy dự đoán chi tiết với tất cả chứng cứ"""
    response = requests.get(f"{API_HOST}/predict?interval={interval}&trading_type={trading_type}")
    if response.status_code == 200:
        data = response.json()
        
        print("\n" + "=" * 70)
        trading_label = "🟢 SPOT" if trading_type == 'spot' else "🔵 FUTURES"
        print(f"📊 DETAILED PREDICTION ({data.get('interval', interval).upper()} {trading_label})")
        print("=" * 70)
        
        # Main signal
        print(f"\n🎯 MAIN SIGNAL: {data['signal']}")
        print(f"📈 Confidence: {data['confidence_percent']}")
        
        # Model predictions
        print(f"\n🤖 MODEL PREDICTIONS:")
        for model, pred in data['models'].items():
            emoji = "🟢" if pred['prediction'] == 'UP' else "🔴"
            print(f"   {model.upper():3s}: {emoji} {pred['prediction']} "
                  f"(UP: {pred['probability_up']:.2%}, Confidence: {pred['confidence']:.2%})")
        
        # Ensemble
        ensemble = data['ensemble']
        print(f"\n🎲 ENSEMBLE VOTE:")
        print(f"   Consensus: {ensemble['model_consensus']} ({ensemble['agreement_percent']})")
        print(f"   Probability UP: {ensemble['probability_up']:.2%}")
        print(f"   Probability DOWN: {ensemble['probability_down']:.2%}")
        
        # Technical Analysis
        print(f"\n📈 TECHNICAL ANALYSIS:")
        tech = data['technical_indicators']
        for tech_name in ["rsi_14", "macd_cross", "ema_trend", "bb_position", "adx_strength", "volume_spike", "mfi", "cci"]:
            if tech_name in tech:
                print(f"   - {data['technical_summary'].get(tech_name, 'N/A')}")
        
        print(f"\n   Tech Consensus: {data['technical_consensus']} ({data['tech_agreement_percent']})")
        
        # Current values
        print(f"\n💰 CURRENT VALUES:")
        cv = data['current_values']
        print(f"   Price: ${cv['price']}")
        print(f"   Volume: {cv['volume']:.0f}")
        print(f"   RSI(14): {cv['rsi_14']:.2f}")
        print(f"   MACD: {cv['macd']:.6f}")
        print(f"   ATR: {cv['atr']:.2f}")
        print(f"   ADX: {cv['adx']:.2f} (Trend Strength)")
        print(f"   BB Position: {cv['bb_position']}")
        
        # Model accuracy
        print(f"\n🏆 MODEL ACCURACY (on test set):")
        for model, acc in data['model_info']['model_accuracy'].items():
            print(f"   {model.upper():10s}: {acc}")
        
        print("\n" + "=" * 70 + "\n")
        return data
    else:
        print(f"❌ Error: {response.json()}")
        return None

def get_prediction_summary(interval='1h', trading_type='spot'):
    """Lấy dự đoán với summary ngắn gọn"""
    response = requests.get(f"{API_HOST}/predict/summary?interval={interval}&trading_type={trading_type}")
    if response.status_code == 200:
        data = response.json()
        trading_label = "🟢 SPOT" if trading_type == 'spot' else "🔵 FUT"
        print(f"[{data['interval'].upper()} {trading_label}] {data['signal']} | Confidence: {data['confidence_percent']} "
              f"| Models: {data['model_consensus']} | Tech: {data['tech_consensus']} "
              f"| Price: ${data['price']:.2f}")
        return data
    else:
        print(f"❌ Error: {response.json()}")
        return None

def get_latest_data(interval='1h'):
    """Lấy dữ liệu mới nhất với features"""
    response = requests.get(f"{API_HOST}/data/latest?interval={interval}")
    if response.status_code == 200:
        data = response.json()
        print(f"📈 Latest data ({interval.upper()}): {len(data)} records")
        for record in data[-3:]:  # In 3 records mới nhất
            print(json.dumps(record, indent=2))
        return data
    else:
        print(f"❌ Error: {response.json()}")

def get_ohlcv(interval='1h'):
    """Lấy dữ liệu OHLCV để vẽ biểu đồ"""
    response = requests.get(f"{API_HOST}/data/ohlcv?interval={interval}")
    if response.status_code == 200:
        data = response.json()
        print(f"📊 OHLCV data ({interval.upper()}): {len(data)} candles")
        return data
    else:
        print(f"❌ Error: {response.json()}")

def get_training_status():
    """Xem status của continuous training"""
    response = requests.get(f"{API_HOST}/training/status")
    if response.status_code == 200:
        data = response.json()
        print(f"🤖 Training Status:")
        print(f"   - Is Training: {data['is_training']}")
        print(f"   - Total Trainings: {data['total_trainings']}")
        print(f"   - Last Training: {data['last_training_time']}")
        print(f"   - Interval: {data['interval_minutes']} minutes")
        return data
    else:
        print(f"❌ Error: {response.json()}")

def compare_all_timeframes():
    """Bandingkan prediksi untuk semua timeframes"""
    intervals = ['15m', '30m', '1h', '4h', '1d']
    
    print("\n" + "=" * 70)
    print("📊 PREDICTIONS ACROSS ALL TIMEFRAMES")
    print("=" * 70)
    
    results = {}
    for interval in intervals:
        response = requests.get(f"{API_HOST}/predict/summary?interval={interval}")
        if response.status_code == 200:
            results[interval] = response.json()
        else:
            print(f"❌ Error fetching {interval}")
    
    # Print table
    print(f"\n{'Interval':<10} {'Signal':<15} {'Confidence':<15} {'Models':<10} {'Tech':<10}")
    print("-" * 60)
    
    for interval in intervals:
        if interval in results:
            r = results[interval]
            print(f"{interval:<10} {r['signal']:<15} {r['confidence_percent']:<15} "
                  f"{r['model_consensus']:<10} {r['tech_consensus']:<10}")
    
    return results

def get_system_info():
    """Get system information"""
    response = requests.get(f"{API_HOST}/info")
    if response.status_code == 200:
        data = response.json()
        print("\n" + "=" * 70)
        print("ℹ️  SYSTEM INFORMATION")
        print("=" * 70)
        print(f"Service: {data['service']}")
        print(f"Version: {data['version']}")
        print(f"Supported Intervals: {', '.join(data['supported_intervals'])}")
        print(f"Supported Trading Types: {', '.join(data.get('supported_trading_types', ['spot', 'future']))}")
        print(f"\nEndpoints:")
        for endpoint, description in data['endpoints'].items():
            print(f"  {endpoint:<30} - {description}")
        return data

def compare_spot_vs_futures(interval='1h'):
    """Bandingkan prediksi spot vs futures untuk interval yang sama"""
    print("\n" + "=" * 70)
    print(f"📊 SPOT vs FUTURES COMPARISON ({interval.upper()})")
    print("=" * 70)
    
    results = {}
    for trading_type in ['spot', 'future']:
        response = requests.get(f"{API_HOST}/predict/summary?interval={interval}&trading_type={trading_type}")
        if response.status_code == 200:
            results[trading_type] = response.json()
        else:
            print(f"❌ Error fetching {trading_type}")
    
    # Print table header
    print(f"\n{'Type':<15} {'Signal':<15} {'Confidence':<15} {'Models':<10} {'Price':<15}")
    print("-" * 70)
    
    if 'spot' in results:
        r = results['spot']
        print(f"{'🟢 SPOT':<15} {r['signal']:<15} {r['confidence_percent']:<15} "
              f"{r['model_consensus']:<10} ${r['price']:.2f}")
    
    if 'future' in results:
        r = results['future']
        print(f"{'🔵 FUTURES':<15} {r['signal']:<15} {r['confidence_percent']:<15} "
              f"{r['model_consensus']:<10} ${r['price']:.2f}")
    
    return results

def health_check():
    """Kiểm tra xem server có chạy không"""
    response = requests.get(f"{API_HOST}/health")
    if response.status_code == 200:
        print("✅ Server is healthy")
        return True
    else:
        print("❌ Server is down")
        return False

if __name__ == "__main__":
    print("=" * 70)
    print("🚀 Crypto AI API Client - SPOT & FUTURES Examples")
    print("=" * 70)
    
    # Health check
    if not health_check():
        print("\n⚠️  Make sure the Flask server is running!")
        print("   python app/main.py")
        exit(1)
    
    # System info
    get_system_info()
    
    # Example 1: Spot vs Futures comparison for 1h
    print("\n" + "=" * 70)
    print("EXAMPLE 1: Compare SPOT vs FUTURES for 1h timeframe")
    print("=" * 70)
    compare_spot_vs_futures(interval='1h')
    
    # Example 2: Detailed spot prediction
    print("\n" + "=" * 70)
    print("EXAMPLE 2: Detailed SPOT prediction (4h)")
    print("=" * 70)
    get_detailed_prediction(interval='4h', trading_type='spot')
    
    # Example 3: Detailed futures prediction
    print("\n" + "=" * 70)
    print("EXAMPLE 3: Detailed FUTURES prediction (15m)")
    print("=" * 70)
    get_detailed_prediction(interval='15m', trading_type='future')
    
    # Example 4: Compare all timeframes (spot only for simplicity)
    print("\n" + "=" * 70)
    print("EXAMPLE 4: All timeframes comparison (SPOT)")
    print("=" * 70)
    compare_all_timeframes()
    
    # Example 5: Quick summaries for different scenarios
    print("\n" + "=" * 70)
    print("EXAMPLE 5: Quick summaries - Different trading scenarios")
    print("=" * 70)
    print("\n📍 Spot Trading Predictions:")
    for interval in ['15m', '1h', '1d']:
        get_prediction_summary(interval=interval, trading_type='spot')
    
    print("\n📍 Futures Trading Predictions:")
    for interval in ['15m', '1h', '1d']:
        get_prediction_summary(interval=interval, trading_type='future')

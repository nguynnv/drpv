# 🤖 Telegram Bot - Setup Instructions

## ⚠️ First Time Setup

### Step 1: Install Dependencies

```bash
# Install Telegram bot library
pip install -r requirements-telegram.txt

# Or install directly
pip install python-telegram-bot==20.4
```

### Step 2: Create Telegram Bot

1. Open Telegram and search for **@BotFather**
2. Send `/newbot`
3. Choose a name and username
4. You'll get a **BOT TOKEN** (save this!)
5. To get your **ADMIN ID**: Search for **@userinfobot** and start it

Example:
- Bot Token: `8776894140:AAHNCWCUPvNjyMmYD43kSSNnSrOUXBRzPd8`
- Admin ID: `7102292124`

### Step 3: Update Configuration

Edit `telegram_bot.py`:

```python
# Line 19-22
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"  # Replace with your token
ADMIN_ID = YOUR_ADMIN_ID            # Replace with your admin ID
API_BASE = "http://localhost:5000"  # API server address
```

### Step 4: Verify File Structure

```
crypto-ai/
├── app/
│   ├── main.py              ← Flask API server
│   ├── data.py
│   ├── features.py
│   ├── model.py
│   └── train.py
├── telegram_bot.py          ← Main bot file
├── user_manager.py          ← User management
├── admin_panel.py           ← Admin functionality
├── backtester.py            ← Backtesting system
├── result_tracker.py        ← Result evaluation
├── start_telegram_bot.py    ← Quick start script
└── data.json                ← Will be auto-created
```

## 🚀 Running the Bot

### Option 1: Manual Start (Recommended for Development)

```bash
# Terminal 1: Start Flask API
python app/main.py

# Terminal 2: Start Telegram Bot
python telegram_bot.py

# Terminal 3 (Optional): Start Result Tracker
python result_tracker.py
```

### Option 2: Quick Start Script

```bash
python start_telegram_bot.py
```

This will automatically start:
1. ✅ Verify Flask API is running
2. ✅ Start Telegram Bot
3. ✅ Start Result Tracker
4. ✅ Display status

## 📱 Test the Bot

1. Open Telegram app
2. Search for your bot username
3. Send `/start`
4. Should see welcome message with buttons

Expected response:
```
👋 Chào mừng username!

Đây là bot dự đoán giá crypto AI...

🎯 Dự đoán  |  📊 Thống kê
❓ Hướng dẫn  |  ⚙️ Cài đặt
```

## ⚙️ Configuration

### user_manager.py

Default configuration - no changes needed:
```python
DATA_FILE = "data.json"  # User data storage
```

### backtester.py

Default configuration - no changes needed:
```python
BACKTEST_FILE = "backtest_results.json"
```

### result_tracker.py

Adjust evaluation timing (optional):
```python
# Check interval (seconds) - default 5 minutes
self.check_interval = 300

# Evaluation time based on intervals
eval_time_map = {
    '15m': timedelta(minutes=30),   # Check after 30 mins
    '30m': timedelta(hours=1),      # Check after 1 hour
    '1h': timedelta(hours=2),       # Check after 2 hours
    '4h': timedelta(hours=8),       # Check after 8 hours
    '1d': timedelta(days=2)         # Check after 2 days
}
```

## 📊 Monitoring

### Check User Data

```bash
# View users
cat data.json

# View backtest results
cat backtest_results.json

# View logs (console output)
# Watch for: [Bot logs], [API calls], [Evaluations]
```

### Monitor Model Quality

During bot operation, watch console for:
```
📊 Evaluated 2 predictions
  - abc123: UP → UP (✅ WIN)
  - def456: DOWN → UP (❌ LOSS)
📈 Model trend: 📈 IMPROVING
```

## 🔧 Troubleshooting

### Issue: Bot doesn't start

**Solution:**
```bash
# Check token validity
# Verify internet connection
# Verify Flask API is running: curl http://localhost:5000/health
```

### Issue: Predictions returning error

**Solution:**
```bash
# Check Flask API logs
# Verify data.py can fetch from Binance
# Check: curl http://localhost:5000/data/ohlcv?interval=1h
```

### Issue: Result tracker not evaluating

**Solution:**
```bash
# Verify result_tracker.py is running (separate terminal)
# Check backtest_results.json for pending predictions
# Verify timeframe has passed (15m pred evaluated after 30m)
```

### Issue: Admin commands not working

**Solution:**
```python
# Verify your user ID matches ADMIN_ID in telegram_bot.py
# Get ID from @userinfobot on Telegram
# Restart bot after changing ADMIN_ID
```

## 📈 Usage Examples

### User: Get Prediction

```
/predict
→ Select timeframe (15m, 1h, 4h)
→ Select trading type (Spot, Futures)
→ Receive prediction + indicators
```

### Admin: Broadcast Message

```
/admin
→ Select "📢 Gửi thông báo"
→ Type message
→ Message sent to all active users
```

### Admin: Blacklist User

```
/admin
→ Select "🚫 Chặn người dùng"
→ Enter user ID
→ User added to blacklist
```

### Admin: Check Model Quality

```
/admin
→ Select "📊 Chất lượng mô hình"
→ View: Win rate, Profit factor, Rating
→ Decide if can auto-publish
```

## 📝 Log Examples

### Normal Operation

```
2024-04-13 10:35:00 - Bot started
✅ Flask API is ready
🚀 Telegram Bot started
📊 Result Tracker started
[10:35:15] User 123456 started bot
[10:36:00] User 123456 requested prediction (1h, spot)
[10:36:05] Prediction returned: 🟢 UP (75%)
[10:36:10] Prediction recorded in backtest
[10:41:00] Result evaluation: UP → UP (WIN, +0.23%)
```

### Error Case

```
[10:35:00] ❌ Flask API not running
⚠️  Starting bot anyway...
[10:36:05] Prediction error: Failed to fetch data
[10:36:10] Sent error message to user
```

## 🔐 Security Considerations

1. **Bot Token** - Keep private, don't share
2. **Admin ID** - Only you and admins
3. **user data** - Local storage (data.json)
4. **API Keys** - Not stored in bot (uses local Flask API)

## 📞 Support

For issues:
1. Check bot logs in console
2. Review troubleshooting section above
3. Verify Flask API is running and accessible
4. Check Binance API status

## 🎯 Next Steps

After setup:
1. ✅ Make first prediction with `/predict`
2. ✅ Check stats with `/stats`
3. ✅ Monitor model quality improvement
4. ✅ Use admin panel to manage users
5. ✅ Review backtest results in backtest_results.json

---

**Last Updated**: 2024-04-13  
**Bot Version**: 1.0  
**Status**: Ready for Production

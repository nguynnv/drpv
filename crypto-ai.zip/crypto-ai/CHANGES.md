"""
WHAT CHANGED - Tóm tắt các thay đổi từ FastAPI sang Flask + Continuous Training

1️⃣ FASTAPI → FLASK
   ❌ Old: FastAPI (async, complex routing)
   ✅ New: Flask (simple, lightweight, perfect for ML apps)
   📊 Lợi ích: Đơn giản hơn, dễ debug, ít dependencies

2️⃣ THÊM CONTINUOUS TRAINING
   ❌ Old: Phải chạy train.py manual mỗi lần
   ✅ New: APScheduler chạy training background mỗi 60 phút (tùy chỉnh được)
   📊 Lợi ích: Models luôn được cập nhật với dữ liệu mới

3️⃣ THÊM DATA SHARING APIs
   ❌ Old: Chỉ có /predict endpoint
   ✅ New: 
      - /data/latest → Dữ liệu mới nhất (50 records)
      - /data/ohlcv → Candles cho biểu đồ
      - /training/status → Xem status training
      - /health → Health check
   📊 Lợi ích: Các app khác có thể dùng dữ liệu

4️⃣ THREADING & BACKGROUND TASKS
   ❌ Old: Đơn luồng, /predict có thể bị chậm nếu training chạy
   ✅ New: Background thread cho training, HTTP requests không bị block
   📊 Lợi ích: Fast responses, training không ảnh hưởng API

FILES CHANGED/CREATED:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📝 requirements.txt - UPDATED
   - Removed: fastapi, uvicorn
   + Added: flask, apscheduler

📝 app/main.py - COMPLETELY REWRITTEN
   OLD:
   ┌─────────────────────────────────────────────┐
   │ from fastapi import FastAPI                 │
   │ app = FastAPI()                             │
   │ @app.get("/predict")                        │
   │ def get_prediction():                       │
   │     ...return predict(...)                  │
   └─────────────────────────────────────────────┘
   
   NEW:
   ┌──────────────────────────────────────────────┐
   │ from flask import Flask                      │
   │ app = Flask(__name__)                        │
   │ @app.route('/predict', methods=['GET'])      │
   │ def get_prediction():                        │
   │     ...return jsonify(predict(...))          │
   │                                              │
   │ # Plus 4 new endpoints + continuous trainer │
   │ @app.route('/data/latest')                   │
   │ @app.route('/data/ohlcv')                    │
   │ @app.route('/training/status')               │
   │ @app.route('/health')                        │
   └──────────────────────────────────────────────┘

✨ app/continuous_trainer.py - NEW FILE
   Handles background training using APScheduler
   - Chạy train() mỗi X phút
   - không block API requests
   - Track training status & history

✨ config.py - NEW FILE
   Centralized configuration
   - Port, host, debug mode
   - Training interval
   - Model paths, limits, logging

✨ client_example.py - NEW FILE
   Example code để các app khác dùng API
   - Health check
   - Get prediction
   - Get latest data
   - Get OHLCV
   - Get training status

HOW IT WORKS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Timeline khi bạn chạy `python main.py`:

   T=0s:
   ├─ Flask server start
   ├─ APScheduler initialize
   └─ Continuous trainer start
      │
      ├─ Train lần 1 (ở T=0)
      │  ├─ Load latest data
      │  │  (mở port 5000)  ← Sẵn sàng nhận requests từ now
      │  ├─ Add features
      │  ├─ Fit 3 models (XGB, RF, LR)
      │  └─ Save models
      │
      └─ Schedule next training (ở T=60 phút)

   T=60s:
   ├─ In background: Train lần 2
   │  └─ Nhưng API vẫn chạy, không bị block
   │
   └─ Other apps @ port 5000:
      ├─ GET /predict → lấy dự đoán
      ├─ GET /data/latest → lấy giá mới
      ├─ GET /data/ohlcv → lấy cho biểu đồ
      └─ GET /training/status → xem training status

DATA FLOW:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

   [Binance API]
        ↓ (data.py)
   [Historical & Real-time Data]
        ↓ (features.py)
   [+ RSI, EMA, MACD, Return]
        ↑                  ↓
    [Training Loop]   [/data/latest]
   (every 60 min)     [/data/ohlcv]
        ↓              (streaming to apps)
   [3 Trained Models]
   (xgb.pkl, rf.pkl,  ↓
    lr.pkl)      [/predict endpoint]
                     ↓
            [Other Apps use data on port 5000]

NEXT STEPS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. pip install -r requirements.txt
2. python app/main.py
3. curl http://localhost:5000/predict
4. Other apps: requests.get('http://localhost:5000/data/latest')

Happy coding! 🚀
"""

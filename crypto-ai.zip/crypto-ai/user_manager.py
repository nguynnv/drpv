"""
User management system for Telegram bot
Saves/loads user IDs and manages user data
"""
import json
import os
from datetime import datetime
from typing import Dict, List, Set

DATA_FILE = "data.json"

class UserManager:
    def __init__(self):
        self.users = self._load_users()
        self.blacklist = self._load_blacklist()
    
    def _load_users(self) -> Dict:
        """Load users from data.json"""
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get('users', {})
        return {}
    
    def _load_blacklist(self) -> Set[int]:
        """Load blacklisted users"""
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return set(data.get('blacklist', []))
        return set()
    
    def _save_data(self):
        """Save all data to data.json"""
        data = {
            'users': self.users,
            'blacklist': list(self.blacklist),
            'last_updated': datetime.now().isoformat()
        }
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def add_user(self, user_id: int, username: str = None, language: str = 'en') -> bool:
        """Add new user (on /start command)"""
        user_id_str = str(user_id)
        if user_id_str not in self.users:
            self.users[user_id_str] = {
                'user_id': user_id,
                'username': username,
                'language': language,
                'joined_at': datetime.now().isoformat(),
                'prediction_count': 0,
                'predictions': []
            }
            self._save_data()
            return True
        return False
    
    def get_user(self, user_id: int) -> Dict:
        """Get user info"""
        return self.users.get(str(user_id))
    
    def set_user_language(self, user_id: int, language: str) -> bool:
        """Set user's preferred language"""
        user_id_str = str(user_id)
        if user_id_str in self.users:
            self.users[user_id_str]['language'] = language
            self._save_data()
            return True
        return False
    
    def get_user_language(self, user_id: int, default: str = 'en') -> str:
        """Get user's preferred language"""
        user_id_str = str(user_id)
        if user_id_str in self.users:
            return self.users[user_id_str].get('language', default)
        return default
    
    def record_prediction(self, user_id: int, prediction_data: Dict):
        """Record a prediction for user"""
        user_id_str = str(user_id)
        if user_id_str in self.users:
            self.users[user_id_str]['prediction_count'] += 1
            self.users[user_id_str]['predictions'].append(prediction_data)
            self._save_data()
    
    def blacklist_user(self, user_id: int) -> bool:
        """Add user to blacklist"""
        if user_id not in self.blacklist:
            self.blacklist.add(user_id)
            self._save_data()
            return True
        return False
    
    def unblacklist_user(self, user_id: int) -> bool:
        """Remove user from blacklist"""
        if user_id in self.blacklist:
            self.blacklist.remove(user_id)
            self._save_data()
            return True
        return False
    
    def is_blacklisted(self, user_id: int) -> bool:
        """Check if user is blacklisted"""
        return user_id in self.blacklist
    
    def get_all_users(self) -> List[int]:
        """Get all active (non-blacklisted) user IDs"""
        return [int(uid) for uid in self.users.keys() 
                if int(uid) not in self.blacklist]
    
    def get_stats(self) -> Dict:
        """Get user statistics"""
        total_users = len(self.users)
        active_users = len(self.get_all_users())
        blacklisted = len(self.blacklist)
        total_predictions = sum(
            user.get('prediction_count', 0) 
            for user in self.users.values()
        )
        
        return {
            'total_users': total_users,
            'active_users': active_users,
            'blacklisted': blacklisted,
            'total_predictions': total_predictions
        }
    
    def get_blacklist(self) -> List[int]:
        """Get list of blacklisted user IDs"""
        return sorted(list(self.blacklist))

# Global instance
user_manager = UserManager()

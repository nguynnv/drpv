"""
Backtesting system for prediction evaluation
Simulates orders and tracks prediction accuracy
"""
import json
import os
from datetime import datetime, timedelta
from typing import Dict, List
from app.data import get_data
import time

BACKTEST_FILE = "backtest_results.json"

class BacktestResult:
    def __init__(self, prediction_id: str, symbol: str, interval: str, 
                 trading_type: str, predicted_signal: str, confidence: float):
        self.prediction_id = prediction_id
        self.symbol = symbol
        self.interval = interval
        self.trading_type = trading_type
        self.predicted_signal = predicted_signal
        self.confidence = confidence
        self.entry_price = None
        self.entry_time = None
        self.exit_price = None
        self.exit_time = None
        self.actual_signal = None
        self.win = None
        self.pnl_percent = None
        self.status = "pending"  # pending, completed, failed
    
    def to_dict(self) -> Dict:
        return {
            'prediction_id': self.prediction_id,
            'symbol': self.symbol,
            'interval': self.interval,
            'trading_type': self.trading_type,
            'predicted_signal': self.predicted_signal,
            'confidence': self.confidence,
            'entry_price': self.entry_price,
            'entry_time': self.entry_time,
            'exit_price': self.exit_price,
            'exit_time': self.exit_time,
            'actual_signal': self.actual_signal,
            'win': self.win,
            'pnl_percent': self.pnl_percent,
            'status': self.status
        }

class Backtester:
    def __init__(self):
        self.results = self._load_results()
    
    def _load_results(self) -> Dict[str, BacktestResult]:
        """Load backtest results from file"""
        if os.path.exists(BACKTEST_FILE):
            with open(BACKTEST_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                results = {}
                for pred_id, result_data in data.get('results', {}).items():
                    result = BacktestResult(
                        pred_id,
                        result_data['symbol'],
                        result_data['interval'],
                        result_data['trading_type'],
                        result_data['predicted_signal'],
                        result_data['confidence']
                    )
                    result.entry_price = result_data.get('entry_price')
                    result.entry_time = result_data.get('entry_time')
                    result.exit_price = result_data.get('exit_price')
                    result.exit_time = result_data.get('exit_time')
                    result.actual_signal = result_data.get('actual_signal')
                    result.win = result_data.get('win')
                    result.pnl_percent = result_data.get('pnl_percent')
                    result.status = result_data.get('status', 'pending')
                    results[pred_id] = result
                return results
        return {}
    
    def _save_results(self):
        """Save backtest results"""
        data = {
            'results': {pid: result.to_dict() for pid, result in self.results.items()},
            'last_updated': datetime.now().isoformat()
        }
        with open(BACKTEST_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def record_prediction(self, prediction_id: str, symbol: str, interval: str,
                         trading_type: str, predicted_signal: str, 
                         confidence: float, entry_price: float) -> BacktestResult:
        """Record a new prediction for later evaluation"""
        result = BacktestResult(
            prediction_id, symbol, interval, trading_type,
            predicted_signal, confidence
        )
        result.entry_price = entry_price
        result.entry_time = datetime.now().isoformat()
        result.status = "pending"
        
        self.results[prediction_id] = result
        self._save_results()
        return result
    
    def evaluate_prediction(self, prediction_id: str, exit_price: float) -> Dict:
        """Evaluate prediction after time has passed"""
        if prediction_id not in self.results:
            return {'error': 'Prediction not found'}
        
        result = self.results[prediction_id]
        result.exit_price = exit_price
        result.exit_time = datetime.now().isoformat()
        result.status = "completed"
        
        # Determine actual signal
        if exit_price > result.entry_price:
            result.actual_signal = "UP"
        elif exit_price < result.entry_price:
            result.actual_signal = "DOWN"
        else:
            result.actual_signal = "NEUTRAL"
        
        # Check if prediction was correct
        result.win = (result.predicted_signal == result.actual_signal)
        
        # Calculate PnL
        if result.predicted_signal == "UP":
            result.pnl_percent = ((exit_price - result.entry_price) / result.entry_price) * 100
        else:  # DOWN
            result.pnl_percent = ((result.entry_price - exit_price) / result.entry_price) * 100
        
        self._save_results()
        
        return {
            'prediction_id': prediction_id,
            'predicted': result.predicted_signal,
            'actual': result.actual_signal,
            'win': result.win,
            'pnl_percent': round(result.pnl_percent, 2)
        }
    
    def get_model_quality(self) -> Dict:
        """Calculate model quality metrics"""
        completed = [r for r in self.results.values() if r.status == "completed"]
        
        if not completed:
            return {
                'total_predictions': 0,
                'completed': 0,
                'pending': len([r for r in self.results.values() if r.status == "pending"]),
                'win_rate': 0,
                'profit_factor': 0,
                'avg_pnl': 0
            }
        
        wins = sum(1 for r in completed if r.win)
        win_rate = (wins / len(completed)) * 100 if completed else 0
        
        profits = [r.pnl_percent for r in completed if r.pnl_percent > 0]
        losses = [abs(r.pnl_percent) for r in completed if r.pnl_percent < 0]
        
        total_profit = sum(profits) if profits else 0
        total_loss = sum(losses) if losses else 0
        profit_factor = (total_profit / total_loss) if total_loss > 0 else (1 if total_profit > 0 else 0)
        
        avg_pnl = sum(r.pnl_percent for r in completed) / len(completed) if completed else 0
        
        return {
            'total_predictions': len(self.results),
            'completed': len(completed),
            'pending': len([r for r in self.results.values() if r.status == "pending"]),
            'win_rate': round(win_rate, 2),
            'profit_factor': round(profit_factor, 2),
            'avg_pnl': round(avg_pnl, 2),
            'total_wins': wins,
            'total_losses': len(completed) - wins
        }
    
    def get_quality_rating(self) -> Dict:
        """Get quality rating for publishing to users"""
        quality = self.get_model_quality()
        
        # Rating system: green flag if win rate > 55% and good profit factor
        win_rate = quality['win_rate']
        profit_factor = quality['profit_factor']
        completed = quality['completed']
        
        if completed < 10:
            rating = "🟡 INSUFFICIENT DATA"
            can_publish = False
        elif win_rate >= 60 and profit_factor >= 1.5:
            rating = "🟢 EXCELLENT"
            can_publish = True
        elif win_rate >= 55 and profit_factor >= 1.0:
            rating = "🟢 GOOD"
            can_publish = True
        elif win_rate >= 52:
            rating = "🟡 FAIR"
            can_publish = False
        else:
            rating = "🔴 POOR"
            can_publish = False
        
        return {
            'rating': rating,
            'can_publish': can_publish,
            'confidence_threshold': 0.70 if can_publish else 0.85,
            'win_rate': win_rate,
            'profit_factor': profit_factor
        }
    
    def cleanup_old_results(self, days: int = 30):
        """Remove predictions older than N days"""
        cutoff_date = datetime.now() - timedelta(days=days)
        
        to_remove = []
        for pred_id, result in self.results.items():
            if result.status == "completed":
                exit_time = datetime.fromisoformat(result.exit_time)
                if exit_time < cutoff_date:
                    to_remove.append(pred_id)
        
        for pred_id in to_remove:
            del self.results[pred_id]
        
        if to_remove:
            self._save_results()
        
        return len(to_remove)

# Global instance
backtester = Backtester()

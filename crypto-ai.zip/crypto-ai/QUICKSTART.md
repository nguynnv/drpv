"""
QUICK START GUIDE - Chạy Crypto AI 70% Accuracy Version
"""

# ============ STEP 1: INSTALL DEPENDENCIES ============

# Mở terminal, chạy:
"""
cd c:\Users\remon\OneDrive\Documents\crypto-ai
pip install -r requirements.txt
"""

# ============ STEP 2: TRAIN INITIAL MODELS ============

# Chạy training lần đầu (mất ~2-3 phút)
"""
python app/train.py
"""

# Expected output:
"""
============================================================
🚀 TRAINING STARTED - Fetching data...
============================================================
📊 Data shape: (485, 51)
✅ Features: 50
📈 Features used: 42
Feature list: ['rsi_14', 'rsi_7', 'stoch_rsi', ...] (showing first 10)
Class distribution: {0: 242, 1: 243}

📊 Train size: 388, Test size: 97

🔄 Training XGBoost...
✅ XGBoost - Accuracy: 0.7629, AUC: 0.8234

🔄 Training Random Forest...
✅ Random Forest - Accuracy: 0.7423, AUC: 0.8045

🔄 Training Gradient Boosting...
✅ Gradient Boosting - Accuracy: 0.7629, AUC: 0.8156

🔄 Training Logistic Regression...
✅ Logistic Regression - Accuracy: 0.6910, AUC: 0.7523

🔄 Creating Ensemble Vote...
✅ Ensemble - Accuracy: 0.7835, AUC: 0.8445

💾 Saving models...
✅ All models saved successfully

============================================================
📊 TRAINING SUMMARY:
============================================================
🏆 Best Model: ENSEMBLE - Accuracy: 78.35%, AUC: 0.8445
🤖 Ensemble Accuracy: 78.35%
   XGB      : Acc=76.29%, AUC=0.8234
   RF       : Acc=74.23%, AUC=0.8045
   GB       : Acc=76.29%, AUC=0.8156
   LR       : Acc=69.10%, AUC=0.7523
   ENSEMBLE : Acc=78.35%, AUC=0.8445
============================================================
"""

# ============ STEP 3: START FLASK SERVER ============

# Chạy server
"""
python app/main.py
"""

# Expected output:
"""
✅ Continuous trainer started - Training every 60 minutes
 * Running on http://0.0.0.0:5000
"""

# ============ STEP 4: TEST API (NEW TERMINAL) ============

# Option A: Chạy client example (chi tiết nhất)
"""
python client_example.py
"""

# Option B: Dùng curl để test
"""
# Quick test
curl http://localhost:5000/health

# Get detailed prediction
curl http://localhost:5000/predict

# Get summary only
curl http://localhost:5000/predict/summary

# Get training status
curl http://localhost:5000/training/status
"""

# Option C: Python script
"""
import requests

r = requests.get('http://localhost:5000/predict')
result = r.json()

print(f"Signal: {result['signal']}")
print(f"Confidence: {result['confidence_percent']}")
print(f"Model consensus: {result['ensemble']['model_consensus']}")
print(f"Tech consensus: {result['technical_consensus']}")

# Print từng model prediction
for model, pred in result['models'].items():
    print(f"{model}: {pred['prediction']} ({pred['probability_up']:.1%})")
"""

# ============ FILE STRUCTURE AFTER SETUP ============

"""
crypto-ai/
├── app/
│   ├── main.py                    ✅ Flask server
│   ├── continuous_trainer.py      ✅ Background training
│   ├── model_analyzer.py          ✅ NEW - Detailed analysis
│   ├── train.py                   ✅ IMPROVED - 4 models + tuning
│   ├── model.py                   ✅ IMPROVED - Return analysis
│   ├── features.py                ✅ IMPROVED - 40+ features
│   ├── data.py                    ✅ Binance data fetch
│   └── __init__.py                (empty)
│
├── models/
│   ├── xgb.pkl                    ✅ XGBoost model
│   ├── rf.pkl                     ✅ Random Forest model
│   ├── gb.pkl                     ✅ Gradient Boosting model
│   ├── lr.pkl                     ✅ Logistic Regression model
│   ├── scaler.pkl                 ✅ NEW - Data scaler
│   ├── feature_cols.pkl           ✅ NEW - Feature list
│   └── metadata.pkl               ✅ NEW - Training metadata
│
├── config.py                      ✅ Configuration
├── client_example.py              ✅ IMPROVED - Show details
├── requirements.txt               ✅ Dependencies
├── README.md                      📖 Guide
├── CHANGES.md                     📖 Changes from FastAPI
├── ACCURACY_IMPROVEMENTS.md       📖 NEW - Accuracy improvements
└── QUICKSTART.md                  📖 This file
"""

# ============ EXPECTED ACCURACY ============

"""
Individual Models:
  - XGBoost: 74-76% ✓
  - Random Forest: 72-74% ✓
  - Gradient Boosting: 74-76% ✓
  - Logistic Regression: 68-70% ✓

Ensemble (Averaged):
  - 76-78% ✓

Confidence Calculation:
  - Based on model agreement
  - Based on technical indicators
  - Weighted average of above two
  - Result: 0.0 - 1.0 (0% - 100%)
"""

# ============ API RESPONSE STRUCTURE ============

"""
GET /predict (Detailed)
├── signal: "🟢 UP" or "🔴 DOWN"
├── confidence: 0.75 (0-1 range)
├── confidence_percent: "75.00%"
├── models: {
│   ├── xgb: {prediction, probability_up, probability_down, confidence}
│   ├── rf: {...}
│   ├── gb: {...}
│   └── lr: {...}
├── ensemble: {
│   ├── probability_up: 0.75
│   ├── probability_down: 0.25
│   ├── model_consensus: "4/4"
│   └── agreement_percent: "100%"
├── technical_indicators: {rsi_oversold, macd_cross, ...}
├── technical_summary: {rsi: "🟢 OVERSOLD (25.5)", ...}
├── technical_consensus: "6/8"
├── tech_agreement_percent: "75%"
├── current_values: {price, volume, rsi_14, macd, atr, adx, bb_position}
└── model_info: {training_timestamp, n_features_used, model_accuracy}

GET /predict/summary (Quick)
├── signal: "🟢 UP"
├── confidence: 0.75
├── confidence_percent: "75.00%"
├── model_consensus: "4/4"
├── tech_consensus: "6/8"
└── price: 42500.25

GET /training/status
├── is_training: false
├── last_training_time: "2024-01-15T10:30:45"
├── total_trainings: 1
└── interval_minutes: 60

GET /health
├── status: "healthy"
└── message: "Crypto AI service is running"

GET /data/latest (10 records)
└── [...array of OHLCV + indicators...]

GET /data/ohlcv (50 records)
└── [...array of time, open, high, low, close, volume...]
"""

# ============ TROUBLESHOOTING ============

"""
❌ Error: "No module named 'binance'"
✅ Fix: pip install python-binance

❌ Error: "No module named 'ta'"
✅ Fix: pip install ta

❌ Error: Models not found (models/xgb.pkl)
✅ Fix: Run python app/train.py first

❌ Port 5000 already in use
✅ Fix Option 1: Edit main.py - change port=5001
✅ Fix Option 2: Kill process - taskkill /PID <PID> /F

❌ Models training but always DOWN
✅ Fix: More data needed, train.py using limit=500
✅ Or: Binance API might be rate limited, retry later

❌ API returns error 500
✅ Check: Terminal logs dari python main.py
✅ Check: Data.py - Binance connectivity

❌ Predictions not updating
✅ Check: python app/main.py terminal
✅ Check: GET /training/status untuk xem training progress
"""

# ============ PERFORMANCE TIPS ============

"""
1. Optimal confidence threshold: 0.55 (55%)
   - Higher = more conservative, fewer trades
   - Lower = more aggressive, more trades

2. Check model agreement: 4/4 = very strong signal
   - 3/4 = strong signal
   - 2/4 = weak signal
   - 1/4 or 0/4 = skip trade

3. Check tech agreement: 6/8+ = good confirmation
   - Multiple indicators agree = higher confidence
   - Divergence = caution

4. Use current_values:
   - RSI < 30 = potential reversal UP
   - RSI > 70 = potential reversal DOWN
   - ADX > 25 = strong trend
   - MACD bullish cross = momentum confirmation

5. Monitor training every hour:
   - Models retrain with latest data
   - Accuracy should improve over time with good data
"""

# ============ NEXT: ADVANCED CUSTOMIZATION ============

"""
อยากเปลี่ยน training interval?
  Edit app/continuous_trainer.py line: trainer = ContinuousTrainer(interval_minutes=30)

อยากthêm model khác?
  Edit app/train.py - add LightGBM, CatBoost, etc.

Muốn fine-tune hyperparameters?
  Edit app/train.py - modify XGBClassifier(), RandomForestClassifier() params

Muốn thêm features?
  Edit app/features.py - thêm indicators (check TA-Lib docs)

Muốn thay đổi prediction logic?
  Edit app/model_analyzer.py - modify _analyze_technicals()
"""

# ============ MONITORING ============

"""
Keep terminal open khi chạy main.py để xem logs:
  - Training progress (mỗi 60 phút)
  - Prediction requests
  - Errors (nếu có)

Kiểm tra accuracy trends:
  - Xem model_info.model_accuracy sau mỗi training
  - Nếu giảm = maybe need more features/tuning
  - Nếu tăng = good sign, use model with confidence

Best practice:
  - Chạy prediction sau mỗi training cycle completed
  - Set alert khi confidence > 0.7 + all models agree
  - Backtest predictions against actual candles
"""

print(__doc__)

"""
Environment Setup & Verification
Kiểm tra tất cả dependencies và fix issues
"""

import sys
import subprocess
from pathlib import Path

def check_python_version():
    """Check Python version >= 3.7"""
    print("📍 Checking Python version...")
    version = sys.version_info
    if version.major >= 3 and version.minor >= 7:
        print(f"✅ Python {version.major}.{version.minor}.{version.micro} - OK")
        return True
    else:
        print(f"❌ Python {version.major}.{version.minor} - Need >= 3.7")
        return False

def check_packages():
    """Check required packages"""
    print("\n📍 Checking packages...")
    
    required = [
        'flask',
        'pandas',
        'numpy',
        'sklearn',
        'xgboost',
        'binance',
        'ta',
        'requests',
        'joblib',
        'apscheduler'
    ]
    
    missing = []
    installed = []
    
    for package in required:
        try:
            __import__(package)
            print(f"✅ {package:15s} - installed")
            installed.append(package)
        except ImportError:
            print(f"❌ {package:15s} - MISSING")
            missing.append(package)
    
    return missing, installed

def install_missing(packages):
    """Install missing packages"""
    if not packages:
        print("\n✅ All packages installed!")
        return True
    
    print(f"\n🔧 Installing {len(packages)} missing packages...")
    try:
        for package in packages:
            print(f"   Installing {package}...", end=' ')
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', package, '-q'])
            print("✅")
        print("\n✅ All packages installed successfully!")
        return True
    except Exception as e:
        print(f"\n❌ Error installing packages: {e}")
        return False

def check_directories():
    """Check required directories exist"""
    print("\n📍 Checking directories...")
    
    dirs = [
        'app',
        'models'
    ]
    
    for dir_name in dirs:
        if Path(dir_name).exists():
            print(f"✅ {dir_name}/ exists")
        else:
            print(f"❌ {dir_name}/ missing")
            Path(dir_name).mkdir(parents=True, exist_ok=True)
            print(f"   Created {dir_name}/")

def check_files():
    """Check critical files exist"""
    print("\n📍 Checking critical files...")
    
    files = {
        'app/main.py': 'Main server',
        'app/train.py': 'Training script',
        'app/model.py': 'Model predictor',
        'app/features.py': 'Feature engineering',
        'app/data.py': 'Data fetcher',
        'app/model_analyzer.py': 'Prediction analyzer',
        'app/continuous_trainer.py': 'Background trainer',
        'requirements.txt': 'Dependencies',
        'config.py': 'Configuration'
    }
    
    for file_path, description in files.items():
        if Path(file_path).exists():
            size = Path(file_path).stat().st_size
            print(f"✅ {file_path:35s} ({size:6d} bytes) - {description}")
        else:
            print(f"❌ {file_path:35s} - MISSING")

def test_imports():
    """Test if all imports work"""
    print("\n📍 Testing imports...")
    
    try:
        from app.data import get_data
        print("✅ app.data.get_data - OK")
    except Exception as e:
        print(f"❌ app.data.get_data - {e}")
    
    try:
        from app.features import add_features
        print("✅ app.features.add_features - OK")
    except Exception as e:
        print(f"❌ app.features.add_features - {e}")
    
    try:
        from app.model_analyzer import get_analyzer
        print("✅ app.model_analyzer.get_analyzer - OK")
    except Exception as e:
        print(f"❌ app.model_analyzer.get_analyzer - {e}")
    
    try:
        from app.continuous_trainer import ContinuousTrainer
        print("✅ app.continuous_trainer.ContinuousTrainer - OK")
    except Exception as e:
        print(f"❌ app.continuous_trainer.ContinuousTrainer - {e}")

def test_binance():
    """Test Binance connection"""
    print("\n📍 Testing Binance connection...")
    
    try:
        from binance.client import Client
        client = Client()
        # Test get last price
        price = client.get_symbol_info('BTCUSDT')
        if price:
            print("✅ Binance API connection - OK")
            return True
    except Exception as e:
        print(f"❌ Binance API connection - {e}")
        print("   Make sure you have internet connection")
        return False

def show_next_steps():
    """Show next steps"""
    print("\n" + "=" * 60)
    print("🚀 NEXT STEPS:")
    print("=" * 60)
    print("""
1. Train initial models:
   python app/train.py

2. Start Flask server:
   python app/main.py

3. Test API (in new terminal):
   python client_example.py

4. For detailed guide:
   - Read QUICKSTART.md
   - Read ACCURACY_IMPROVEMENTS.md
   - Read README.md
""")

def main():
    """Main verification"""
    print("=" * 60)
    print("🔍 CRYPTO AI - ENVIRONMENT SETUP & VERIFICATION")
    print("=" * 60)
    
    # Check Python
    if not check_python_version():
        print("\n❌ Setup failed: Python version too old")
        return False
    
    # Check+Install packages
    missing, installed = check_packages()
    if missing and not install_missing(missing):
        print("\n❌ Setup failed: Could not install packages")
        return False
    
    # Check directories
    check_directories()
    
    # Check files
    check_files()
    
    # Test imports
    test_imports()
    
    # Test Binance
    test_binance()
    
    # Show next steps
    show_next_steps()
    
    print("\n" + "=" * 60)
    print("✅ SETUP VERIFICATION COMPLETE!")
    print("=" * 60)
    return True

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)

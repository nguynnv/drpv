"""
LumyX Trader - Telegram Bot for Crypto AI Predictions
Multi-timeframe predictions with futures support & multi-language support
"""
import logging
import requests
import uuid
from datetime import datetime
from typing import Dict

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, PhotoSize, InputFile
from telegram.constants import ChatAction
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes, ConversationHandler, MessageHandler, filters

from user_manager import user_manager, UserManager
from backtester import backtester, Backtester
from admin_panel import AdminPanel
from language_manager import language_manager, t

# Configuration
BOT_TOKEN = "8776894140:AAHNCWCUPvNjyMmYD43kSSNnSrOUXBRzPd8"
ADMIN_ID = 7102292124
API_BASE = "http://localhost:5000"

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Conversation states
SELECTING_TIMEFRAME, SELECTING_TYPE = range(2)
ADMIN_BROADCAST_MSG, ADMIN_BROADCAST_IMG, ADMIN_BLACKLIST_ID = range(3, 6)

class CryptoAIBot:
    def __init__(self):
        self.admin_panel = AdminPanel(ADMIN_ID)
        self.app = Application.builder().token(BOT_TOKEN).build()
        self.setup_handlers()
    
    def setup_handlers(self):
        """Setup all command and button handlers"""
        # Command handlers
        self.app.add_handler(CommandHandler("start", self.start))
        self.app.add_handler(CommandHandler("predict", self.predict_command))
        self.app.add_handler(CommandHandler("stats", self.stats))
        self.app.add_handler(CommandHandler("admin", self.admin_menu))
        self.app.add_handler(CommandHandler("help", self.help_command))
        
        # Admin broadcast conversation handler
        admin_broadcast_handler = ConversationHandler(
            entry_points=[CallbackQueryHandler(self.admin_broadcast_start, pattern="^admin_broadcast$")],
            states={
                ADMIN_BROADCAST_MSG: [MessageHandler(filters.TEXT & ~filters.COMMAND, self.admin_broadcast_msg)],
                ADMIN_BROADCAST_IMG: [
                    MessageHandler(filters.PHOTO, self.admin_broadcast_with_img),
                    CallbackQueryHandler(self.admin_broadcast_callback, pattern="^broadcast_")
                ]
            },
            fallbacks=[CallbackQueryHandler(self.button_callback, pattern="^main_menu$")]
        )
        self.app.add_handler(admin_broadcast_handler)
        
        # Callback handlers for buttons
        self.app.add_handler(CallbackQueryHandler(self.button_callback))
    
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command - register user"""
        user = update.effective_user
        user_id = user.id
        username = user.username or user.first_name
        
        # Add user to manager (default language: English)
        is_new = user_manager.add_user(user_id, username, language='en')
        
        # Get user language
        user_lang = user_manager.get_user_language(user_id, 'en')
        
        # Get welcome text
        if is_new:
            welcome_text = t(user_lang, 'start_welcome').format(username=username)
        else:
            welcome_text = t(user_lang, 'start_welcome_returning').format(username=username)
        
        keyboard = [
            [
                InlineKeyboardButton(t(user_lang, 'btn_predict'), callback_data="start_predict"),
                InlineKeyboardButton(t(user_lang, 'btn_stats'), callback_data="show_stats")
            ],
            [
                InlineKeyboardButton(t(user_lang, 'btn_help'), callback_data="help"),
                InlineKeyboardButton(t(user_lang, 'btn_language'), callback_data="select_language")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Handle both /start command and main_menu button
        if update.callback_query:
            await update.callback_query.edit_message_text(
                welcome_text,
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
        else:
            await update.message.reply_text(
                welcome_text,
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
    
    async def predict_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /predict command"""
        await self.start_prediction(update, context)
    
    async def start_prediction(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start prediction workflow"""
        user_id = update.effective_user.id
        user_lang = user_manager.get_user_language(user_id, 'en')
        
        # Check if blacklisted
        if user_manager.is_blacklisted(user_id):
            if update.callback_query:
                await update.callback_query.answer(
                    t(user_lang, 'error_blacklisted'),
                    show_alert=True
                )
            else:
                await update.message.reply_text(t(user_lang, 'error_blacklisted'))
            return
        
        # Show timeframe selection
        keyboard = [
            [
                InlineKeyboardButton(t(user_lang, 'tf_15m'), callback_data="time_15m"),
                InlineKeyboardButton(t(user_lang, 'tf_30m'), callback_data="time_30m")
            ],
            [
                InlineKeyboardButton(t(user_lang, 'tf_1h'), callback_data="time_1h"),
                InlineKeyboardButton(t(user_lang, 'tf_4h'), callback_data="time_4h")
            ],
            [
                InlineKeyboardButton(t(user_lang, 'tf_1d'), callback_data="time_1d")
            ],
            [
                InlineKeyboardButton(t(user_lang, 'btn_back'), callback_data="main_menu")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        text = t(user_lang, 'select_timeframe')
        
        if update.callback_query:
            await update.callback_query.edit_message_text(text, reply_markup=reply_markup)
        else:
            await update.message.reply_text(text, reply_markup=reply_markup)
        
        return SELECTING_TIMEFRAME
    
    async def button_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle all button callbacks"""
        query = update.callback_query
        user_id = update.effective_user.id
        user_lang = user_manager.get_user_language(user_id, 'en')
        
        await query.answer()  # Remove loading state
        
        if query.data == "main_menu":
            await self.start(update, context)
        
        elif query.data == "start_predict":
            await self.start_prediction(update, context)
        
        elif query.data == "select_language":
            # Show language selection
            languages = language_manager.get_available_languages()
            keyboard = []
            for lang_code, lang_name in languages.items():
                keyboard.append([InlineKeyboardButton(lang_name, callback_data=f"lang_{lang_code}")])
            keyboard.append([InlineKeyboardButton(t(user_lang, 'btn_back'), callback_data="main_menu")])
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                t(user_lang, 'language_select'),
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
        
        elif query.data.startswith("lang_"):
            # Change language
            new_lang = query.data.split("_")[1]
            user_manager.set_user_language(user_id, new_lang)
            user_lang = new_lang
            
            await query.edit_message_text(
                t(user_lang, 'language_changed').format(language=language_manager.get_available_languages()[new_lang]),
                parse_mode='Markdown'
            )
            
            # Back to main menu after 1 second
            import asyncio
            await asyncio.sleep(1)
            await self.start(update, context)
        
        elif query.data == "show_stats":
            stats = user_manager.get_stats()
            quality = backtester.get_quality_rating()
            quality_metrics = backtester.get_model_quality()
            
            text = (
                t(user_lang, 'stats_title') + "\n\n"
                + t(user_lang, 'stats_users') + "\n"
                + t(user_lang, 'stats_total').format(total=stats['total_users']) + "\n"
                + t(user_lang, 'stats_active').format(active=stats['active_users']) + "\n"
                + t(user_lang, 'stats_blocked').format(blocked=stats['blacklisted']) + "\n\n"
                + t(user_lang, 'stats_predictions') + "\n"
                + t(user_lang, 'stats_total_pred').format(total=stats['total_predictions']) + "\n"
                + t(user_lang, 'stats_win_rate').format(wr=quality_metrics['win_rate']) + "\n"
                + t(user_lang, 'stats_profit_factor').format(pf=quality_metrics['profit_factor']) + "\n\n"
                + t(user_lang, 'stats_model_quality').format(rating=quality['rating'])
            )
            
            keyboard = [[InlineKeyboardButton(t(user_lang, 'btn_back'), callback_data="main_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')
        
        elif query.data == "help":
            help_text = (
                t(user_lang, 'help_title') + "\n\n"
                + t(user_lang, 'help_predict') + "\n\n"
                + t(user_lang, 'help_stats') + "\n\n"
                + t(user_lang, 'help_indicators')
            )
            
            keyboard = [[InlineKeyboardButton(t(user_lang, 'btn_back'), callback_data="main_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(help_text, reply_markup=reply_markup, parse_mode='Markdown')
        
        # Timeframe selection
        elif query.data.startswith("time_"):
            interval = query.data.split("_")[1]  # 15m, 30m, 1h, 4h, 1d
            context.user_data['interval'] = interval
            
            # Ask for trading type
            keyboard = [
                [
                    InlineKeyboardButton(t(user_lang, 'btn_spot'), callback_data="trade_spot"),
                    InlineKeyboardButton(t(user_lang, 'btn_futures'), callback_data="trade_future")
                ],
                [
                    InlineKeyboardButton(t(user_lang, 'btn_back'), callback_data="start_predict")
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                t(user_lang, 'select_trading_type').format(interval=interval.upper()),
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
        
        # Trading type selection
        elif query.data.startswith("trade_"):
            trading_type = query.data.split("_")[1]  # spot or future
            interval = context.user_data.get('interval', '1h')
            
            await self.get_prediction(update, context, interval, trading_type)
        
        # Admin handlers
        elif query.data == "admin_blacklist":
            await self.admin_blacklist_start(update, context)
        
        elif query.data == "admin_users":
            await self.admin_list_users(update, context)
        
        elif query.data == "admin_quality":
            await self.admin_show_quality(update, context)
    
    async def get_prediction(self, update: Update, context: ContextTypes.DEFAULT_TYPE,
                            interval: str, trading_type: str):
        """Fetch prediction from API and display"""
        query = update.callback_query
        user_id = update.effective_user.id
        user_lang = user_manager.get_user_language(user_id, 'en')
        
        # Show loading message
        await query.edit_message_text(t(user_lang, 'analyzing'), parse_mode='Markdown')
        
        try:
            # Call API
            response = requests.get(
                f"{API_BASE}/predict",
                params={'interval': interval, 'trading_type': trading_type},
                timeout=10
            )
            
            if response.status_code != 200:
                await query.edit_message_text(t(user_lang, 'error_prediction'))
                return
            
            data = response.json()
            signal = data['signal']
            confidence_percent = data['confidence_percent']
            confidence = data['confidence']
            
            # Extract key metrics (excluding model accuracy)
            price = data['current_values']['price']
            rsi = data['current_values']['rsi_14']
            macd = data['current_values']['macd']
            atr = data['current_values']['atr']
            adx = data['current_values']['adx']
            
            # Format prediction message
            trading_label = t(user_lang, 'btn_spot') if trading_type == 'spot' else t(user_lang, 'btn_futures')
            
            text = (
                t(user_lang, 'prediction_title') + "\n\n"
                + t(user_lang, 'prediction_symbol') + "\n"
                + t(user_lang, 'prediction_interval').format(interval=interval.upper()) + "\n"
                + t(user_lang, 'prediction_type').format(type=trading_label) + "\n\n"
                + t(user_lang, 'prediction_result') + "\n"
                + signal + "\n"
                + t(user_lang, 'prediction_confidence').format(confidence=confidence_percent) + "\n\n"
                + t(user_lang, 'prediction_indicators') + "\n"
                + t(user_lang, 'prediction_price').format(price=price) + "\n"
                + t(user_lang, 'prediction_rsi').format(rsi=rsi) + "\n"
                + t(user_lang, 'prediction_macd').format(macd=macd) + "\n"
                + t(user_lang, 'prediction_atr').format(atr=atr) + "\n"
                + t(user_lang, 'prediction_adx').format(adx=adx) + "\n\n"
                + t(user_lang, 'prediction_tips') + "\n"
            )
            
            # Add technical recommendations
            if rsi > 70:
                text += t(user_lang, 'prediction_rsi_high') + "\n"
            elif rsi < 30:
                text += t(user_lang, 'prediction_rsi_low') + "\n"
            
            if adx > 25:
                text += t(user_lang, 'prediction_adx_strong') + "\n"
            else:
                text += t(user_lang, 'prediction_adx_weak') + "\n"
            
            # Record prediction for backtesting
            pred_id = str(uuid.uuid4())[:8]
            backtester.record_prediction(
                pred_id, 'BTCUSDT', interval, trading_type,
                'UP' if '🟢' in signal else 'DOWN',
                confidence,
                price
            )
            
            # Record in user manager
            user_manager.record_prediction(user_id, {
                'prediction_id': pred_id,
                'timestamp': datetime.now().isoformat(),
                'interval': interval,
                'trading_type': trading_type,
                'signal': signal,
                'confidence': confidence_percent,
                'price': price
            })
            
            # Check if high confidence and ask admin
            if confidence >= 0.75:
                text += (
                    "\n\n"
                    + t(user_lang, 'prediction_alert').format(confidence=confidence_percent)
                )
            
            # Add buttons for actions
            keyboard = [
                [InlineKeyboardButton(t(user_lang, 'btn_new_prediction'), callback_data="start_predict")],
                [InlineKeyboardButton(t(user_lang, 'btn_stats'), callback_data="show_stats")],
                [InlineKeyboardButton(t(user_lang, 'btn_main_menu'), callback_data="main_menu")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')
        
        except Exception as e:
            logger.error(f"Prediction error: {str(e)}")
            await query.edit_message_text(f"❌ Error: {str(e)}")
    
    async def stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show user statistics"""
        user_id = update.effective_user.id
        user_lang = user_manager.get_user_language(user_id, 'en')
        user = user_manager.get_user(user_id)
        
        if not user:
            await update.message.reply_text(t(user_lang, 'error_no_user'))
            return
        
        pred_count = user['prediction_count']
        text = (
            t(user_lang, 'user_stats_title') + "\n\n"
            + t(user_lang, 'user_stats_name').format(username=user['username']) + "\n"
            + t(user_lang, 'user_stats_joined').format(date=user['joined_at'][:10]) + "\n"
            + t(user_lang, 'user_stats_predictions').format(count=pred_count) + "\n\n"
        )
        
        if pred_count > 0:
            # Get user's prediction accuracy
            text += (
                t(user_lang, 'user_stats_performance')
            )
        
        await update.message.reply_text(text, parse_mode='Markdown')
    
    async def admin_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show admin menu (only for admin)"""
        user_id = update.effective_user.id
        user_lang = user_manager.get_user_language(user_id, 'en')
        
        if user_id != ADMIN_ID:
            await update.message.reply_text(t(user_lang, 'access_denied'))
            return
        
        keyboard = [
            [InlineKeyboardButton(t(user_lang, 'btn_broadcast'), callback_data="admin_broadcast")],
            [InlineKeyboardButton(t(user_lang, 'btn_blacklist'), callback_data="admin_blacklist")],
            [InlineKeyboardButton(t(user_lang, 'btn_users'), callback_data="admin_users")],
            [InlineKeyboardButton(t(user_lang, 'btn_quality'), callback_data="admin_quality")],
            [InlineKeyboardButton(t(user_lang, 'btn_back'), callback_data="main_menu")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            t(user_lang, 'admin_title'),
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show help information"""
        user_id = update.effective_user.id
        user_lang = user_manager.get_user_language(user_id, 'en')
        
        help_text = (
            t(user_lang, 'help_title') + "\n\n"
            + "/start - " + t(user_lang, 'start_welcome') + "\n"
            + "/predict - " + t(user_lang, 'help_predict') + "\n"
            + "/stats - " + t(user_lang, 'help_stats') + "\n"
            + "/admin - " + t(user_lang, 'admin_title') + "\n"
            + "/help - " + t(user_lang, 'help_title') + "\n"
        )
        await update.message.reply_text(help_text, parse_mode='Markdown')
    
    # ==================== ADMIN FUNCTIONS ====================
    
    async def admin_broadcast_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start broadcast conversation"""
        query = update.callback_query
        user_id = update.effective_user.id
        user_lang = user_manager.get_user_language(user_id, 'en')
        
        if user_id != ADMIN_ID:
            await query.answer(t(user_lang, 'access_denied'), show_alert=True)
            return
        
        await query.answer()
        await query.edit_message_text(
            "📢 *Nhập nội dung thông báo:*",
            parse_mode='Markdown'
        )
        return ADMIN_BROADCAST_MSG
    
    async def admin_broadcast_msg(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle broadcast message text"""
        user_id = update.effective_user.id
        user_lang = user_manager.get_user_language(user_id, 'en')
        
        # Store message
        context.user_data['broadcast_msg'] = update.message.text
        
        # Ask about image
        keyboard = [
            [InlineKeyboardButton("📷 Thêm hình ảnh", callback_data="broadcast_add_img")],
            [InlineKeyboardButton("✅ Gửi thôi", callback_data="broadcast_send")],
            [InlineKeyboardButton("❌ Hủy", callback_data="main_menu")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            "📢 *Nội dung:*\n" + update.message.text + "\n\n*Thêm hình ảnh?*",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        return ADMIN_BROADCAST_IMG
    
    async def admin_broadcast_with_img(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle broadcast with image"""
        user_id = update.effective_user.id
        user_lang = user_manager.get_user_language(user_id, 'en')
        
        # Store image
        context.user_data['broadcast_img'] = update.message.photo[-1].file_id
        
        # Confirm and send
        await self.broadcast_to_users(context, user_lang)
        
        await update.message.reply_text("✅ *Thông báo đã gửi!*", parse_mode='Markdown')
        return ConversationHandler.END
    
    async def admin_broadcast_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle broadcast button callbacks"""
        query = update.callback_query
        user_id = update.effective_user.id
        user_lang = user_manager.get_user_language(user_id, 'en')
        
        await query.answer()
        
        if query.data == "broadcast_send":
            # Send without image
            await self.broadcast_to_users(context, user_lang)
            await query.edit_message_text("✅ *Thông báo đã gửi!*", parse_mode='Markdown')
            return ConversationHandler.END
        
        elif query.data == "broadcast_add_img":
            # Show image upload prompt
            await query.edit_message_text(
                "📷 *Gửi hình ảnh (hoặc nhấn /cancel để bỏ)*",
                parse_mode='Markdown'
            )
            return ADMIN_BROADCAST_IMG
    
    async def broadcast_to_users(self, context: ContextTypes.DEFAULT_TYPE, user_lang: str):
        """Send broadcast to all users"""
        broadcast_msg = context.user_data.get('broadcast_msg')
        broadcast_img = context.user_data.get('broadcast_img')
        
        all_users = user_manager.get_all_users()
        sent = 0
        failed = 0
        
        for uid in all_users:
            try:
                target_lang = user_manager.get_user_language(uid, 'en')
                
                if broadcast_img:
                    await context.bot.send_photo(
                        chat_id=uid,
                        photo=broadcast_img,
                        caption=f"📢 *Thông báo từ Admin:*\n\n{broadcast_msg}",
                        parse_mode='Markdown'
                    )
                else:
                    await context.bot.send_message(
                        chat_id=uid,
                        text=f"📢 *Thông báo từ Admin:*\n\n{broadcast_msg}",
                        parse_mode='Markdown'
                    )
                sent += 1
            except Exception as e:
                logger.error(f"Failed to send broadcast to {uid}: {str(e)}")
                failed += 1
        
        # Clear user data
        context.user_data.clear()
    
    async def admin_blacklist_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start blacklist management"""
        query = update.callback_query
        user_id = update.effective_user.id
        
        if user_id != ADMIN_ID:
            await query.answer("❌ Chỉ admin có quyền", show_alert=True)
            return
        
        # Show current blacklist
        blacklist = user_manager.get_blacklist()
        
        if blacklist:
            text = "🚫 *Danh sách chặn:*\n\n"
            for bid in blacklist:
                text += f"• {bid}\n"
        else:
            text = "✅ *Danh sách chặn trống*\n\n"
        
        text += "\n*Nhập User ID để:*"
        
        keyboard = [
            [InlineKeyboardButton("➕ Chặn user", callback_data="blacklist_add")],
            [InlineKeyboardButton("➖ Bỏ chặn user", callback_data="blacklist_remove")],
            [InlineKeyboardButton("🔙 Quay lại", callback_data="main_menu")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')
    
    async def admin_list_users(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show all users list"""
        query = update.callback_query
        user_id = update.effective_user.id
        
        if user_id != ADMIN_ID:
            await query.answer("❌ Chỉ admin có quyền", show_alert=True)
            return
        
        stats = user_manager.get_stats()
        
        text = f"👥 *Quản lý Người dùng*\n\n"
        text += f"📊 *Tổng:* {stats['total_users']}\n"
        text += f"✅ *Hoạt động:* {stats['active_users']}\n"
        text += f"🚫 *Bị chặn:* {stats['blacklisted']}\n"
        text += f"🎯 *Dự đoán:* {stats['total_predictions']}\n"
        
        keyboard = [[InlineKeyboardButton("🔙 Quay lại", callback_data="main_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')
    
    async def admin_show_quality(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show model quality details"""
        query = update.callback_query
        user_id = update.effective_user.id
        
        if user_id != ADMIN_ID:
            await query.answer("❌ Chỉ admin có quyền", show_alert=True)
            return
        
        quality = backtester.get_quality_rating()
        metrics = backtester.get_model_quality()
        
        text = f"📊 *Chất lượng Mô hình*\n\n"
        text += f"⭐ *Đánh giá:* {quality['rating']}\n"
        text += f"📈 *Tỷ lệ thắng:* {metrics['win_rate']:.1f}%\n"
        text += f"💰 *Profit Factor:* {metrics['profit_factor']:.2f}\n"
        text += f"✅ *Hoàn thành:* {metrics.get('completed_predictions', 0)}\n"
        
        keyboard = [[InlineKeyboardButton("🔙 Quay lại", callback_data="main_menu")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')
    
    def run(self):
        """Start the bot"""
        print("\n" + "="*70)
        print("🚀 LumyX Trader - Starting")
        print("="*70)
        print(f"Bot ID: {BOT_TOKEN.split(':')[0]}")
        print(f"Admin ID: {ADMIN_ID}")
        print(f"API Base: {API_BASE}")
        print("="*70 + "\n")
        
        self.app.run_polling(allowed_updates=Update.ALL_TYPES)

# Create bot instance
bot = CryptoAIBot()

if __name__ == '__main__':
    bot.run()

# 🤖 Crypto AI Telegram Bot

Telegram bot tích hợp với hệ thống dự đoán giá crypto. Bot cung cấp dự đoán UP/DOWN với các chỉ báo kỹ thuật hỗ trợ.

## ✨ Tính Năng

### 👤 Người Dùng
- **🎯 Dự đoán giá** - Dự đoán UP/DOWN cho 5 khung thời gian (15m, 30m, 1h, 4h, 1d)
- **💰 Hỗ trợ Spot & Futures** - Dự đoán riêng biệt cho Spot trading và Futures
- **📊 Chỉ báo kỹ thuật** - Hiển thị RSI, MACD, EMA, ADX, ATR để hỗ trợ quyết định
- **📈 Thống kê** - Xem tỷ lệ thắng, profit factor, và hiệu suất mô hình
- **💾 Lưu lịch sử** - Tất cả dự đoán được lưu vào data.json

### ⚙️ Admin Panel
- **📢 Gửi thông báo** - Broadcast message tới tất cả người dùng
- **🚫 Quản lý blacklist** - Chặn/bỏ chặn người dùng
- **👥 Quản lý người dùng** - Xem danh sách người dùng, thống kê
- **📊 Chất lượng mô hình** - Monitoring win rate, profit factor
- **🔔 Dự đoán cao độ tin cậy** - Hỏi admin trước khi phát hành dự đoán
- **✅ Tracking kết quả** - Tự động kiểm tra kết quả dự đoán sau khung thời gian

### 🔍 Model Quality Tracking
- **Backtesting** - Mô phỏng đặt lệnh dựa trên dự đoán
- **Automatic Evaluation** - Kiểm tra kết quả thực tế sau mỗi timeframe
- **Model Improvement** - Tự động điều chỉnh dựa trên kết quả
- **Quality Rating** - Rating từ 🔴 POOR đến 🟢 EXCELLENT

## 🚀 Cài Đặt

### 1. Cài đặt dependencies

```bash
pip install -r requirements-telegram.txt
```

### 2. Cấu hình

Sửa `telegram_bot.py`:
```python
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"  # Lấy từ @BotFather
ADMIN_ID = 7102292124              # Admin user ID
API_BASE = "http://localhost:5000"  # API server address
```

### 3. Chạy bot

```bash
# Terminal 1: Chạy Flask API server
cd app
python main.py

# Terminal 2: Chạy Telegram bot
python telegram_bot.py

# Terminal 3 (Optional): Chạy result tracker (tự động evaluate predictions)
python result_tracker.py
```

## 📁 Cấu Trúc File

```
crypto-ai/
├── telegram_bot.py          # Bot chính
├── user_manager.py          # Quản lý người dùng (data.json)
├── admin_panel.py           # Admin panel
├── backtester.py            # Backtesting system
├── result_tracker.py        # Tự động tracking kết quả
├── data.json                # User data (tự động tạo)
├── backtest_results.json    # Backtest results (tự động tạo)
└── requirements-telegram.txt
```

## 💬 Lệnh Bot

| Lệnh | Mô Tả |
|------|-------|
| `/start` | Khởi động bot & đăng ký người dùng |
| `/predict` | Bắt đầu dự đoán |
| `/stats` | Xem thống kê cá nhân |
| `/admin` | Admin panel (chỉ admin) |
| `/help` | Hiển thị trợ giúp |

## 🎮 Giao Diện

### User Interface
```
┌─────────────────────┐
│  🎯 Dự đoán         │
│  📊 Thống kê        │
│  ❓ Hướng dẫn       │
│  ⚙️ Cài đặt        │
└─────────────────────┘

Chọn khung thời gian (15m, 30m, 1h, 4h, 1d)
  ↓
Chọn loại giao dịch (Spot, Futures)
  ↓
Nhận dự đoán + chỉ báo kỹ thuật
```

### Admin Panel
```
⚙️ ADMIN PANEL
├── 📢 Gửi thông báo
├── 🚫 Chặn người dùng
├── 👥 Quản lý người dùng
├── 📊 Chất lượng mô hình
└── 🔙 Quay lại
```

## 📊 Dữ Liệu Lưu Trữ

### data.json
```json
{
  "users": {
    "123456789": {
      "user_id": 123456789,
      "username": "john_doe",
      "joined_at": "2024-04-13T10:30:00",
      "prediction_count": 5,
      "predictions": [
        {
          "prediction_id": "abc123",
          "timestamp": "2024-04-13T10:35:00",
          "interval": "1h",
          "trading_type": "spot",
          "signal": "🟢 UP",
          "confidence": "75%",
          "price": 42500.50
        }
      ]
    }
  },
  "blacklist": [987654321],
  "last_updated": "2024-04-13T10:35:00"
}
```

### backtest_results.json
```json
{
  "results": {
    "abc123": {
      "prediction_id": "abc123",
      "symbol": "BTCUSDT",
      "interval": "1h",
      "trading_type": "spot",
      "predicted_signal": "UP",
      "confidence": 0.75,
      "entry_price": 42500.50,
      "entry_time": "2024-04-13T10:35:00",
      "exit_price": 42600.00,
      "exit_time": "2024-04-13T11:35:00",
      "actual_signal": "UP",
      "win": true,
      "pnl_percent": 0.23,
      "status": "completed"
    }
  }
}
```

## 🎯 Workflow

### User Workflow
1. User gõ `/start` → Bot đăng ký user ID vào data.json
2. User chọn `/predict` → Chọn timeframe & trading type
3. Bot gọi API lấy dự đoán → Hiển thị signal + chỉ báo
4. Bot ghi lại dự đoán vào backtest_results.json

### Admin Approval Workflow
Nếu dự đoán có confidence >= 75%:
1. Bot gửi message hỏi admin: "Có phát hành cho người dùng không?"
2. Admin bấm "Phát hành" → Bot broadcast tới all users
3. Admin bấm "Từ chối" → Chỉ admin thấy

### Result Tracking Workflow
1. Result tracker chạy mỗi 5 phút
2. Kiểm tra pending predictions
3. Nếu timeframe đã qua → Fetch giá hiện tại từ API
4. So sánh predicted signal với actual signal
5. Cập nhật win/loss & PnL
6. Tính toán model quality metrics
7. Nếu model quality cải thiện → Có thể publish automatic predictions

## 📈 Model Quality System

### Quality Rating
```
🟢 EXCELLENT   | Win Rate >= 60% & Profit Factor >= 1.5
🟢 GOOD        | Win Rate >= 55% & Profit Factor >= 1.0  
🟡 FAIR        | Win Rate >= 52% (cần xem lại)
🔴 POOR        | Win Rate < 52%
🟡 INSUFFICIENT| < 10 completed predictions
```

### Auto-Publish Criteria
- Can publish: EXCELLENT or GOOD rating
- Confidence threshold for auto-publish: 70% (normal) → 85% (if FAIR/POOR)
- Manual approval for high-confidence predictions (>75%)

### Model Improvement Detection
```
📈 IMPROVING   | Current win rate > Previous win rate + 5%
📉 DECLINING   | Current win rate < Previous win rate - 5%
➡️ STABLE      | Better than previous +/- 5%
```

## 🔔 Alert System

### Admin Notifications
1. **High Confidence Prediction** (conf >= 75%)
   - "Dự đoán có độ tin cậy cao, có phát hành?"
2. **Model Improvement Detected**
   - "Mô hình đang cải tiến! Win rate: 55% → 58%"
3. **Model Degradation Alert**
   - "⚠️ Mô hình đang suy giảm, cần review"

### User Notifications (from Admin)
- Broadcast messages
- Daily performance reports (optional)

## 🛡️ Bảo Mật

- Admin ID hardcoded (chỉ admin nhất định truy cập được)
- Blacklist system (ngăn chặn user không mong muốn)
- User data lưu local (data.json)
- No API keys exposed in logs

## 🐛 Troubleshooting

### Bot không start
```bash
# Check token validity
# Check internet connection
# Verify Flask API is running on http://localhost:5000
```

### Dự đoán lỗi
```bash
# Check Flask API logs
# Verify data.py can fetch Binance data
# Check internet connection & Binance API status
```

### Backtest không evaluate
```bash
# Verify result_tracker.py is running
# Check Binance data availability
# Review backtest_results.json for pending predictions
```

## 📝 Log Files

Logs được in ra console:
- Bot events
- User commands
- Prediction evaluations
- Model improvements
- Errors & exceptions

## 🚀 Next Steps

1. ✅ Tích hợp với hệ thống giá real-time
2. ✅ Dashboard web để xem thống kê (optional)
3. ✅ Notifications qua email (optional)
4. ✅ Multi-language support (optional)
5. ✅ Advanced backtesting metrics

---

**Bot Version**: 1.0  
**Created**: 2024-04-13  
**Support**: Integrated with Crypto AI v2.0 API

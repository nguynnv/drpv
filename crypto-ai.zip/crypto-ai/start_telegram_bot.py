#!/usr/bin/env python3
"""
Quick start script for Telegram bot
Runs all components together
"""
import subprocess
import sys
import time
from pathlib import Path

def run_component(cmd, name, cwd=None):
    """Run a component in a separate process"""
    print(f"\n🚀 Starting {name}...")
    try:
        process = subprocess.Popen(
            cmd,
            shell=True,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        print(f"✅ {name} started (PID: {process.pid})")
        return process
    except Exception as e:
        print(f"❌ Failed to start {name}: {str(e)}")
        return None

def main():
    print("=" * 70)
    print("🤖 Crypto AI - Telegram Bot Quick Start")
    print("=" * 70)
    
    # Check prerequisites
    print("\n📋 Checking prerequisites...")
    
    # Check if Flask API is available
    import socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    api_ready = sock.connect_ex(('localhost', 5000)) == 0
    sock.close()
    
    if not api_ready:
        print("⚠️  Flask API not running on localhost:5000")
        print("   Please start Flask API first: python app/main.py")
        return
    
    print("✅ Flask API is ready")
    
    # Get bot token
    bot_token = "8776894140:AAHNCWCUPvNjyMmYD43kSSNnSrOUXBRzPd8"
    admin_id = "7102292124"
    
    print(f"✅ Bot token configured")
    print(f"✅ Admin ID configured: {admin_id}")
    
    processes = []
    
    try:
        # Start Telegram bot
        print("\n" + "=" * 70)
        print("🤖 Starting Telegram Bot")
        print("=" * 70)
        
        bot_process = run_component(
            f"{sys.executable} telegram_bot.py",
            "Telegram Bot"
        )
        if bot_process:
            processes.append(("Telegram Bot", bot_process))
        
        time.sleep(2)
        
        # Start result tracker
        print("\n" + "=" * 70)
        print("📊 Starting Result Tracker")
        print("=" * 70)
        
        tracker_process = run_component(
            f"{sys.executable} result_tracker.py",
            "Result Tracker"
        )
        if tracker_process:
            processes.append(("Result Tracker", tracker_process))
        
        # Display running status
        print("\n" + "=" * 70)
        print("🎉 All components started successfully!")
        print("=" * 70)
        print("\n📱 Bot is now online. Uses like /start or /predict")
        print("\n⚙️  Admin Panel available with /admin command")
        print("\n📊 Results are tracked automatically every 5 minutes")
        print("\nPress Ctrl+C to stop all services")
        print("=" * 70 + "\n")
        
        # Keep processes running
        while True:
            time.sleep(1)
            for name, process in processes:
                if process.poll() is not None:
                    print(f"⚠️  {name} crashed (exit code: {process.poll()})")
    
    except KeyboardInterrupt:
        print("\n\n🛑 Shutting down all components...")
        for name, process in processes:
            print(f"  Stopping {name}...")
            process.terminate()
            process.wait(timeout=5)
        print("✅ All components stopped")
    
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        for name, process in processes:
            process.terminate()

if __name__ == '__main__':
    main()

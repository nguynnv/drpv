"""
Admin panel for bot management
Broadcast messages, manage blacklist, view statistics
"""
from datetime import datetime
from typing import List, Dict
from user_manager import user_manager

class AdminPanel:
    def __init__(self, admin_id: int):
        self.admin_id = admin_id
    
    def is_admin(self, user_id: int) -> bool:
        """Check if user is admin"""
        return user_id == self.admin_id
    
    async def broadcast_message(self, message: str, context) -> Dict:
        """Send message to all active users"""
        users = user_manager.get_all_users()
        
        sent = 0
        failed = 0
        
        for user_id in users:
            try:
                await context.bot.send_message(
                    chat_id=user_id,
                    text=message,
                    parse_mode='Markdown'
                )
                sent += 1
            except Exception as e:
                failed += 1
        
        return {
            'sent': sent,
            'failed': failed,
            'total': len(users),
            'timestamp': datetime.now().isoformat()
        }
    
    def get_blacklist(self) -> List[int]:
        """Get current blacklist"""
        stats = user_manager.get_stats()
        return list(user_manager.blacklist)
    
    def add_to_blacklist(self, user_id: int) -> Dict:
        """Add user to blacklist"""
        user = user_manager.get_user(user_id)
        if not user:
            return {'success': False, 'message': 'Người dùng không tìm thấy'}
        
        user_manager.blacklist_user(user_id)
        return {
            'success': True,
            'message': f"Đã chặn người dùng {user['username']} (ID: {user_id})"
        }
    
    def remove_from_blacklist(self, user_id: int) -> Dict:
        """Remove user from blacklist"""
        user = user_manager.get_user(user_id)
        if not user:
            return {'success': False, 'message': 'Người dùng không tìm thấy'}
        
        if not user_manager.is_blacklisted(user_id):
            return {'success': False, 'message': 'Người dùng không trong danh sách chặn'}
        
        user_manager.unblacklist_user(user_id)
        return {
            'success': True,
            'message': f"Đã bỏ chặn người dùng {user['username']} (ID: {user_id})"
        }
    
    def get_user_list(self, limit: int = 50) -> Dict:
        """Get list of users with pagination"""
        users = user_manager.get_all_users()
        
        formatted_users = []
        for uid in users[:limit]:
            user = user_manager.get_user(uid)
            if user:
                formatted_users.append({
                    'id': uid,
                    'username': user['username'],
                    'joined_at': user['joined_at'][:10],
                    'predictions': user['prediction_count']
                })
        
        return {
            'total_users': len(users),
            'showing': len(formatted_users),
            'users': formatted_users
        }
    
    def get_blacklist_info(self) -> Dict:
        """Get detailed blacklist information"""
        blacklist = user_manager.blacklist
        
        formatted = []
        for uid in blacklist:
            user = user_manager.get_user(uid)
            if user:
                formatted.append({
                    'id': uid,
                    'username': user['username'],
                    'joined_at': user['joined_at'][:10]
                })
        
        return {
            'total_blacklisted': len(blacklist),
            'users': formatted
        }
    
    def get_system_stats(self) -> Dict:
        """Get comprehensive system statistics"""
        stats = user_manager.get_stats()
        
        return {
            'timestamp': datetime.now().isoformat(),
            'users': {
                'total': stats['total_users'],
                'active': stats['active_users'],
                'blacklisted': stats['blacklisted']
            },
            'predictions': {
                'total': stats['total_predictions'],
                'avg_per_user': round(
                    stats['total_predictions'] / stats['active_users']
                    if stats['active_users'] > 0 else 0, 2
                )
            }
        }

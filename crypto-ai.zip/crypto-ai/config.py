"""
Cấu hình cho ứng dụng Crypto AI
"""

# ============ FLASK SERVER CONFIG ============
FLASK_HOST = "0.0.0.0"  # Cho phép connect từ máy khác (0.0.0.0), hoặc localhost nếu chỉ local
FLASK_PORT = 5000       # Port chính để các app khác connect
FLASK_DEBUG = False     # Không dùng debug mode trên production

# ============ CONTINUOUS TRAINING CONFIG ============
TRAINING_INTERVAL_MINUTES = 60   # Train mỗi bao nhiêu phút (hiện tại 60 phút)
AUTO_START_TRAINING = True       # Tự động start training khi server khởi động

# ============ DATA CONFIG ============
DATA_LIMIT_DEFAULT = 100         # Số bars lấy mặc định khi train
PREDICTION_LIMIT = 100            # Số bars để dự đoán
LATEST_DATA_LIMIT = 50            # Số records trả về khi call /data/latest

# ============ MODEL CONFIG ============
MODEL_PATHS = {
    "xgb": "models/xgb.pkl",
    "rf": "models/rf.pkl",
    "lr": "models/lr.pkl"
}

# ============ LOGGING CONFIG ============
LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR, CRITICAL
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'

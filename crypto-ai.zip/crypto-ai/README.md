# 🚀 Crypto AI - Flask + Continuous Training

Ứng dụng machine learning dự đoán cryptocurrency với Flask API và continuous training background.

## ✨ Tính năng

✅ **Flask API** - Thay thế FastAPI, đơn giản hơn, nhẹ hơn  
✅ **Continuous Training** - Tự động train models định kỳ (mỗi 60 phút)  
✅ **Data Sharing** - Các app khác có thể fetch dữ liệu qua HTTP  
✅ **Health Check** - Endpoint kiểm tra server status  
✅ **Training Status** - Xem trạng thái training  

## 📦 Cài đặt

### 1. Cài đặt dependencies

```bash
cd c:\Users\remon\OneDrive\Documents\crypto-ai
pip install -r requirements.txt
```

**Các package mới được thêm:**
- `flask` - Web framework
- `apscheduler` - Scheduling background tasks

### 2. Chạy ứng dụng

```bash
# Từ thư mục app/
python main.py
```

**Output sẽ giống như:**
```
 * Running on http://0.0.0.0:5000
  ✅ Continuous trainer started - Training every 60 minutes
  🚀 Training #1 started
  ✅ Training #1 completed successfully
```

## 🔗 API Endpoints

### 1. **Dự đoán giá** `GET /predict`
```bash
curl http://localhost:5000/predict
```
Response:
```json
{
  "signal": "UP",
  "confidence": 0.75
}
```

### 2. **Dữ liệu mới nhất** `GET /data/latest`
```bash
curl http://localhost:5000/data/latest
```
Trả về 10 records mới nhất với các features (RSI, EMA, MACD, etc.)

### 3. **Dữ liệu OHLCV** `GET /data/ohlcv`
```bash
curl http://localhost:5000/data/ohlcv
```
Trả về 50 candles để vẽ biểu đồ trading

### 4. **Status Training** `GET /training/status`
```bash
curl http://localhost:5000/training/status
```
Response:
```json
{
  "is_training": false,
  "last_training_time": "2024-01-15T10:30:45",
  "total_trainings": 3,
  "interval_minutes": 60
}
```

### 5. **Health Check** `GET /health`
```bash
curl http://localhost:5000/health
```

## 💻 Sử dụng từ App Khác

### Cách 1: Dùng file example

```bash
python client_example.py
```

### Cách 2: Manual requests (Python)

```python
import requests

# Lấy dự đoán
response = requests.get('http://localhost:5000/predict')
prediction = response.json()
print(f"Signal: {prediction['signal']} ({prediction['confidence']:.0%})")

# Lấy dữ liệu
data = requests.get('http://localhost:5000/data/latest').json()
print(f"Latest prices: {data}")
```

### Cách 3: JavaScript/Node.js

```javascript
// Dự đoán
fetch('http://localhost:5000/predict')
  .then(r => r.json())
  .then(data => console.log(`${data.signal} - ${(data.confidence*100).toFixed(1)}%`))

// Dữ liệu
fetch('http://localhost:5000/data/latest')
  .then(r => r.json())
  .then(data => console.log(data))
```

## ⚙️ Tùy chỉnh

Chỉnh sửa file `config.py`:

```python
TRAINING_INTERVAL_MINUTES = 30   # Train mỗi 30 phút thay vì 60
FLASK_PORT = 8000               # Dùng port 8000 thay vì 5000
FLASK_DEBUG = True              # Bật debug mode để phát triển
```

Hoặc chỉnh trực tiếp trong `continuous_trainer.py`:
```python
trainer = ContinuousTrainer(interval_minutes=30)  # Thay số phút ở đây
```

## 📁 Cấu trúc thư mục

```
crypto-ai/
├── app/
│   ├── main.py                 # Flask app chính (NEW - dùng Flask thay FastAPI)
│   ├── continuous_trainer.py   # Background training (NEW)
│   ├── data.py                 # Fetch dữ liệu từ Binance
│   ├── features.py             # Tính technical indicators
│   ├── model.py                # Load models & predict
│   └── train.py                # Train models
├── models/                      # Storage cho trained models
│   ├── xgb.pkl
│   ├── rf.pkl
│   └── lr.pkl
├── config.py                    # Cấu hình (NEW)
├── client_example.py            # Ví dụ sử dụng API (NEW)
├── requirements.txt             # Dependencies (UPDATED - Flask, APScheduler)
└── README.md                    # File này

```

## 🚨 Troubleshooting

### Port 5000 đã bị sử dụng
```bash
# Tìm process đang dùng port 5000
netstat -ano | findstr :5000

# Kill process (bạn có thể dùng config.py để đổi port)
taskkill /PID <PID> /F
```

### Training không chạy
Kiểm tra:
1. Có dữ liệu từ Binance? → Xem `data.py`
2. Models đã tồn tại? → Chạy `python train.py` manual
3. Kiểm tra logs cho error messages

### Không connect được từ app khác
```bash
# Đảm bảo FLASK_HOST = "0.0.0.0" trong main.py
# Thử ping server
curl http://localhost:5000/health

# Nếu từ máy khác, dùng IP thật thay vì localhost
curl http://192.168.x.x:5000/health
```

## 🔧 Dev Mode (nếu cần)

Để phát triển thêm features:

```python
# Bật debug mode tạm thời
app.run(debug=True)  # Auto reload khi sửa code
```

## 📝 Log Files

Logs được in ra terminal. Để lưu logs vào file:

```python
# Thêm vào main.py
import logging
from logging.handlers import RotatingFileHandler

handler = RotatingFileHandler('app.log', maxBytes=10000, backupCount=3)
logging.getLogger().addHandler(handler)
```

## 🔐 Production Tips

1. **Dùng gunicorn thay Flask dev server:**
   ```bash
   pip install gunicorn
   gunicorn -w 4 -b 0.0.0.0:5000 app.main:app
   ```

2. **Lưu logs vào file**

3. **Dùng environment variables:**
   ```python
   import os
   FLASK_PORT = os.getenv('PORT', 5000)
   ```

4. **Rate limiting:**
   ```bash
   pip install Flask-Limiter
   ```

## 📧 Support

Nếu gặp lỗi, check:
- Terminal logs khi chạy `python main.py`
- Xem training status: `curl http://localhost:5000/training/status`
- Kiểm tra dữ liệu mẫu: `curl http://localhost:5000/data/latest`
